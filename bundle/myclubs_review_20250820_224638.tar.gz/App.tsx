import 'react-native-get-random-values';
import React, { useEffect } from 'react';
import './src/i18n';
import { useColorScheme } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Provider as PaperProvider, DefaultTheme as PaperDefaultTheme } from 'react-native-paper';
import { MD3LightTheme as DefaultTheme, MD3DarkTheme as DarkTheme } from 'react-native-paper';
import { configureFonts } from 'react-native-paper';
import { NavigationContainer, DefaultTheme as NavDefaultTheme } from '@react-navigation/native';

import { LanguageProvider } from './src/contexts/LanguageContext';
import { AuthProvider } from './src/contexts/AuthContext';
import { AIChatProvider } from './src/contexts/AIChatContext';
import { LocationProvider } from './src/contexts/LocationContext';
import AppNavigator from './src/navigation/AppNavigator';
import knowledgeBaseService from './src/services/knowledgeBaseService';

// 통합된 라이트 테마 (시스템 모드 무시)
const customPaperTheme = {
  ...PaperDefaultTheme,
  dark: false,
  colors: {
    ...PaperDefaultTheme.colors,
    primary: '#1976d2',
    secondary: '#ff9800',
    background: '#FFFFFF',
    surface: '#FFFFFF',
    text: '#1F2937',
    onSurface: '#1F2937',
    onSurfaceVariant: '#6B7280',
    outline: '#D1D5DB',
    surfaceVariant: '#F3F4F6',
    error: '#DC2626',
    warning: '#F59E0B',
    success: '#10B981',
  },
  fonts: configureFonts({
    isV3: true,
    config: {
      bodyLarge: { fontFamily: 'System', fontWeight: '400', fontSize: 16 },
      bodyMedium: { fontFamily: 'System', fontWeight: '400', fontSize: 14 },
      labelLarge: { fontFamily: 'System', fontWeight: '600', fontSize: 14 },
      titleLarge: { fontFamily: 'System', fontWeight: '700', fontSize: 20 },
    }
  }),
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
  },
};

const customNavTheme = {
  ...NavDefaultTheme,
  dark: false,
  colors: {
    ...NavDefaultTheme.colors,
    primary: '#1976d2',
    background: '#FFFFFF',
    card: '#FFFFFF',
    text: '#1F2937',
    border: '#E5E7EB',
  },
};

export default function App() {

  // Initialize knowledge base on app start
  useEffect(() => {
    const initializeApp = async () => {
      try {
        // Initialize knowledge base for both languages
        await knowledgeBaseService.initializeBothLanguages();
      } catch (error) {
        console.warn('Failed to initialize knowledge base:', error);
      }
    };

    initializeApp();
  }, []);

  return (
    <PaperProvider theme={customPaperTheme}>
      <SafeAreaProvider>
        <LanguageProvider>
          <AuthProvider>
            <LocationProvider>
              <AIChatProvider>
                <NavigationContainer theme={customNavTheme}>
                  <AppNavigator />
                  <StatusBar style="auto" />
                </NavigationContainer>
              </AIChatProvider>
            </LocationProvider>
          </AuthProvider>
        </LanguageProvider>
      </SafeAreaProvider>
    </PaperProvider>
  );
}
