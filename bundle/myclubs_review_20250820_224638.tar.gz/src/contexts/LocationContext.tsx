import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { Platform, Alert } from 'react-native';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface UserLocation {
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: number;
}

interface LocationContextType {
  location: UserLocation | null;
  isLoading: boolean;
  error: string | null;
  requestLocationPermission: () => Promise<boolean>;
  getCurrentLocation: () => Promise<UserLocation | null>;
  watchLocation: () => void;
  stopWatchingLocation: () => void;
  isLocationEnabled: boolean;
}

const LocationContext = createContext<LocationContextType | undefined>(undefined);

export const useLocation = () => {
  const context = useContext(LocationContext);
  if (context === undefined) {
    throw new Error('useLocation must be used within a LocationProvider');
  }
  return context;
};

interface LocationProviderProps {
  children: ReactNode;
}

export const LocationProvider: React.FC<LocationProviderProps> = ({ children }) => {
  const [location, setLocation] = useState<UserLocation | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLocationEnabled, setIsLocationEnabled] = useState(false);
  const [watchId, setWatchId] = useState<number | null>(null);

  useEffect(() => {
    // 앱 시작 시 저장된 위치 정보 로드
    loadCachedLocation();
    
    // 위치 권한 상태 확인
    checkLocationPermission();
  }, []);

  const loadCachedLocation = async () => {
    try {
      const cachedLocation = await AsyncStorage.getItem('userLocation');
      if (cachedLocation) {
        const parsedLocation = JSON.parse(cachedLocation);
        // 24시간 이내의 위치 정보만 사용
        if (Date.now() - parsedLocation.timestamp < 24 * 60 * 60 * 1000) {
          setLocation(parsedLocation);
        }
      }
    } catch (error) {
      console.error('Error loading cached location:', error);
    }
  };

  const checkLocationPermission = async () => {
    try {
      const { status } = await Location.getForegroundPermissionsAsync();
      setIsLocationEnabled(status === 'granted');
    } catch (error) {
      console.error('Error checking location permission:', error);
      setIsLocationEnabled(false);
    }
  };

  const requestLocationPermission = async (): Promise<boolean> => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      const isGranted = status === 'granted';
      setIsLocationEnabled(isGranted);
      
      if (!isGranted) {
        Alert.alert(
          '위치 권한 필요',
          'nearby 플레이어를 찾기 위해 위치 권한이 필요합니다.',
          [{ text: '확인' }]
        );
      }
      
      return isGranted;
    } catch (error) {
      console.error('Error requesting location permission:', error);
      setIsLocationEnabled(false);
      return false;
    }
  };

  const getCurrentLocation = async (): Promise<UserLocation | null> => {
    if (!isLocationEnabled) {
      const hasPermission = await requestLocationPermission();
      if (!hasPermission) {
        setError('위치 권한이 필요합니다.');
        return null;
      }
    }

    setIsLoading(true);
    setError(null);

    try {
      const position = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
        timeInterval: 15000,
        maximumAge: 60000,
      });

      const newLocation: UserLocation = {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracy: position.coords.accuracy || 0,
        timestamp: Date.now(),
      };

      setLocation(newLocation);
      setIsLoading(false);

      // 위치 정보 캐싱
      try {
        await AsyncStorage.setItem('userLocation', JSON.stringify(newLocation));
      } catch (error) {
        console.error('Error caching location:', error);
      }

      return newLocation;
    } catch (error) {
      setIsLoading(false);
      let errorMessage = '위치를 가져올 수 없습니다.';
      
      if (error.code === 'E_LOCATION_SERVICES_DISABLED') {
        errorMessage = '위치 서비스가 비활성화되었습니다.';
      } else if (error.code === 'E_LOCATION_UNAVAILABLE') {
        errorMessage = '위치를 찾을 수 없습니다.';
      } else if (error.code === 'E_LOCATION_TIMEOUT') {
        errorMessage = '위치 요청이 시간 초과되었습니다.';
      }
      
      setError(errorMessage);
      console.error('Location error:', error);
      return null;
    }
  };

  const watchLocation = async () => {
    if (!isLocationEnabled || watchId !== null) return;

    try {
      const subscription = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.Balanced,
          timeInterval: 30000,
          distanceInterval: 100,
        },
        async (position) => {
          const newLocation: UserLocation = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy || 0,
            timestamp: Date.now(),
          };

          setLocation(newLocation);

          // 위치 정보 캐싱
          try {
            await AsyncStorage.setItem('userLocation', JSON.stringify(newLocation));
          } catch (error) {
            console.error('Error caching location:', error);
          }
        }
      );

      setWatchId(subscription as any);
    } catch (error) {
      console.error('Location watch error:', error);
      setError('실시간 위치 추적에 실패했습니다.');
    }
  };

  const stopWatchingLocation = () => {
    if (watchId !== null) {
      if (typeof watchId === 'object' && 'remove' in watchId) {
        (watchId as any).remove();
      }
      setWatchId(null);
    }
  };

  // 컴포넌트 언마운트 시 위치 추적 정리
  useEffect(() => {
    return () => {
      stopWatchingLocation();
    };
  }, [watchId]);

  const value: LocationContextType = {
    location,
    isLoading,
    error,
    requestLocationPermission,
    getCurrentLocation,
    watchLocation,
    stopWatchingLocation,
    isLocationEnabled,
  };

  return (
    <LocationContext.Provider value={value}>
      {children}
    </LocationContext.Provider>
  );
};