/**
 * Auth Context for Lightning Tennis
 * Manages user authentication state
 */

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Firebase imports from central config
import { auth, db } from '../firebase/config';

const isFirebaseAvailable = true;
console.log('🔥 AuthContext: Firebase Auth and Firestore loaded successfully');

interface User {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  skillLevel: string; // NTRP 등급 (예: '3.0-3.5', '4.0-4.5', etc.) - 통합된 실력 레벨
  ntrpLevel: string; // NTRP 레벨 (skillLevel과 동일한 값, 호환성을 위해 별도 필드)
  playingStyle: string;
  maxTravelDistance: number; // 최대 이동 거리 (마일)
  location: {
    lat: number;
    lng: number;
    address?: string;
  } | null;
  activityRegions: string[];
  languages: string[];
  recentMatches: any[];
  goals: string | null;
  isOnboardingComplete?: boolean; // Firestore에 저장된 온보딩 완료 상태
}

interface AuthResult {
  success: boolean;
  error?: string;
  code?: string; // Firebase 에러 코드
  user?: User;
}

interface AuthContextType {
  currentUser: User | null;
  loading: boolean;
  isProfileLoaded: boolean; // 새로운 상태: Firestore 프로필 로딩 완료 여부
  isOnboardingComplete: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<AuthResult>;
  signUpWithEmail: (email: string, password: string) => Promise<AuthResult>;
  signOut: () => Promise<void>;
  updateUserProfile: (updates: Partial<User>) => Promise<void>;
  markOnboardingComplete: (profileData?: Partial<User>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isProfileLoaded, setIsProfileLoaded] = useState(false); // 새로운 상태
  const [isOnboardingComplete, setIsOnboardingComplete] = useState(false);

  // Load user profile from Firestore
  const loadUserProfile = async (firebaseUser: any) => {
    if (!isFirebaseAvailable || !db) {
      console.warn('⚠️ Firebase not available, skipping profile load');
      return;
    }

    try {
      const { doc, getDoc } = await import('firebase/firestore');
      const userDocRef = doc(db, 'users', firebaseUser.uid);
      const userDoc = await getDoc(userDocRef);
      
      if (userDoc.exists()) {
        const userData = userDoc.data();
        console.log('✅ User profile loaded from Firestore:', userData);
        
        // Handle nested profile data structure
        const profileData = userData.profile || userData; // Support both nested and flat structure
        
        // Legacy data migration: convert old ntrpLevel to new skillLevel format
        let unifiedSkillLevel = profileData.skillLevel || userData.skillLevel;
        if (!unifiedSkillLevel && (profileData.ntrpLevel || userData.ntrpLevel)) {
          // Migrate old ntrpLevel to new skillLevel format
          const oldNtrpLevel = profileData.ntrpLevel || userData.ntrpLevel;
          unifiedSkillLevel = oldNtrpLevel; // Use NTRP value as the unified skill level
        }
        if (!unifiedSkillLevel) {
          unifiedSkillLevel = '3.0-3.5'; // Default NTRP level
        }
        
        // Smart onboarding completion detection
        // If user has a nickname (displayName) and basic profile data, consider onboarding complete
        const hasNickname = !!(profileData.nickname || profileData.displayName || userData.displayName);
        const hasBasicProfile = !!(profileData.skillLevel || userData.skillLevel || profileData.activityRegions || userData.activityRegions);
        const smartOnboardingComplete = userData.isOnboardingComplete || (hasNickname && hasBasicProfile);
        
        console.log('🔍 Smart onboarding detection:');
        console.log('   - hasNickname:', hasNickname);
        console.log('   - hasBasicProfile:', hasBasicProfile);
        console.log('   - stored isOnboardingComplete:', userData.isOnboardingComplete);
        console.log('   - smartOnboardingComplete:', smartOnboardingComplete);

        const user: User = {
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          displayName: profileData.nickname || profileData.displayName || userData.displayName || firebaseUser.displayName,
          photoURL: profileData.photoURL || userData.photoURL || firebaseUser.photoURL,
          skillLevel: unifiedSkillLevel, // Unified NTRP skill level
          ntrpLevel: unifiedSkillLevel, // 호환성을 위해 skillLevel과 동일한 값 설정
          playingStyle: profileData.playingStyle || userData.playingStyle || 'all-court',
          maxTravelDistance: profileData.maxTravelDistance || userData.maxTravelDistance || 15,
          location: profileData.location || userData.location || { lat: 33.7490, lng: -84.3880, address: 'Atlanta, GA' },
          activityRegions: profileData.activityRegions || userData.activityRegions || ['Atlanta Metro'],
          languages: profileData.languages || userData.languages || ['English'],
          recentMatches: profileData.recentMatches || userData.recentMatches || [],
          goals: profileData.goals || userData.goals || null,
          isOnboardingComplete: smartOnboardingComplete
        };
        
        setCurrentUser(user);
        setIsOnboardingComplete(smartOnboardingComplete);
        setIsProfileLoaded(true); // ✅ 프로필 로딩 완료!
        console.log(`🏁 Final onboarding status: ${smartOnboardingComplete ? 'Complete' : 'Incomplete'}`);
        console.log(`✅ Profile loaded successfully - isProfileLoaded set to true`);
      } else {
        console.log('📄 No user profile found in Firestore, creating basic profile...');
        // Create basic user profile
        const newUser: User = {
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          displayName: firebaseUser.displayName,
          photoURL: firebaseUser.photoURL,
          skillLevel: '3.0-3.5', // Default NTRP level
          ntrpLevel: '3.0-3.5', // 호환성을 위해 skillLevel과 동일한 값 설정
          playingStyle: 'all-court',
          maxTravelDistance: 15,
          location: { lat: 33.7490, lng: -84.3880, address: 'Atlanta, GA' },
          activityRegions: ['Atlanta Metro'],
          languages: ['English'],
          recentMatches: [],
          goals: null,
          isOnboardingComplete: false
        };
        
        setCurrentUser(newUser);
        setIsOnboardingComplete(false);
        setIsProfileLoaded(true); // ✅ 새 사용자도 프로필 로딩 완료로 간주
        console.log('🏁 New user - onboarding required');
        console.log('✅ New user profile created - isProfileLoaded set to true');
      }
    } catch (error) {
      console.error('❌ Error loading user profile from Firestore:', error);
      throw error;
    }
  };

  // Initialize and check for existing Firebase user session
  useEffect(() => {
    if (isFirebaseAvailable && auth) {
      // Check for existing Firebase user session
      const unsubscribe = auth.onAuthStateChanged(async (firebaseUser) => {
        console.log('🔥 AuthContext: onAuthStateChanged triggered');
        console.log('   - firebaseUser:', firebaseUser ? `${firebaseUser.email} (${firebaseUser.uid})` : 'null');
        
        if (firebaseUser) {
          console.log('🔥 AuthContext: Firebase user found, loading profile...');
          // Keep loading true while fetching Firestore data
          setLoading(true);
          setIsProfileLoaded(false); // 🔄 프로필 로딩 시작
          
          try {
            await loadUserProfile(firebaseUser);
            console.log('✅ Profile loaded successfully - setting loading to false');
          } catch (error) {
            console.error('❌ Error loading user profile:', error);
            // Fallback to basic user data WITHOUT using firebaseUser.displayName
            // This prevents email-based fallbacks like "goodseed1"
            setCurrentUser({
              uid: firebaseUser.uid,
              email: firebaseUser.email,
              displayName: null, // Don't use firebaseUser.displayName to prevent email fallback
              photoURL: firebaseUser.photoURL,
              skillLevel: '3.0-3.5', // Default NTRP level
              ntrpLevel: '3.0-3.5', // 호환성을 위해 skillLevel과 동일한 값 설정
              playingStyle: 'all-court',
              maxTravelDistance: 15,
              location: { lat: 33.7490, lng: -84.3880, address: 'Atlanta, GA' },
              activityRegions: ['Atlanta Metro'],
              languages: ['English'],
              recentMatches: [],
              goals: null,
              isOnboardingComplete: false
            });
            setIsOnboardingComplete(false);
            setIsProfileLoaded(true); // ❌ 에러 발생해도 프로필 로딩 완료로 간주
            console.log('⚠️ Fallback user created without displayName to prevent email-based names');
          } finally {
            // Only set loading to false after Firestore operation completes
            setLoading(false);
          }
        } else {
          console.log('🔥 AuthContext: No Firebase user - authentication required');
          console.log('   - Previous currentUser:', currentUser ? `${currentUser.email}` : 'null');
          // Clear user state when no Firebase user
          setCurrentUser(null);
          setIsOnboardingComplete(false);
          setIsProfileLoaded(false); // 🚮 로그아웃 시 프로필 로딩 상태 초기화
          setLoading(false);
        }
      });

      return () => unsubscribe();
    } else {
      // Mock mode - no user logged in
      setTimeout(() => {
        setCurrentUser(null);
        setIsOnboardingComplete(false);
        setIsProfileLoaded(false); // Mock 모드에서도 초기화
        setLoading(false);
        console.log('🔥 AuthContext: Mock mode - authentication flow required');
      }, 1000);
    }
  }, []);

  const signIn = async (email: string, password: string) => {
    setLoading(true);
    try {
      // Mock sign in
      await new Promise(resolve => setTimeout(resolve, 1000));
      setCurrentUser({
        uid: 'demo-user-123',
        email,
        displayName: 'Demo User',
        photoURL: null,
        skillLevel: '3.0-3.5', // 데모 사용자의 NTRP 등급
        playingStyle: 'all-court',
        maxTravelDistance: 15, // 기본 15마일
        location: {
          lat: 33.7490,
          lng: -84.3880,
          address: 'Atlanta, GA'
        },
        activityRegions: ['Atlanta Metro', 'North Georgia'],
        languages: ['English', '한국어'],
        recentMatches: [],
        goals: null
      });
    } finally {
      setLoading(false);
    }
  };

  const signInWithEmail = async (email: string, password: string): Promise<AuthResult> => {
    try {
      if (isFirebaseAvailable && auth) {
        // Use Firebase Auth
        const { signInWithEmailAndPassword } = await import('firebase/auth');
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        const firebaseUser = userCredential.user;
        
        // Immediately load user profile to avoid race conditions with onAuthStateChanged
        console.log('✅ Firebase email sign in successful - loading profile immediately');
        try {
          await loadUserProfile(firebaseUser);
          console.log('✅ User profile loaded successfully after sign in');
        } catch (error) {
          console.error('❌ Error loading profile after sign in:', error);
        }
        
        return { success: true, user: null }; // User state is already set by loadUserProfile
      } else {
        // Mock authentication
        console.log('⚠️ Using mock email authentication');
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        const user: User = {
          uid: `mock-${Date.now()}`,
          email,
          displayName: 'Mock User',
          photoURL: null,
          skillLevel: '3.0-3.5', // Default NTRP level
          playingStyle: 'all-court',
          maxTravelDistance: 15,
          location: {
            lat: 33.7490,
            lng: -84.3880,
            address: 'Atlanta, GA'
          },
          activityRegions: ['Atlanta Metro', 'North Georgia'],
          languages: ['English', '한국어'],
          recentMatches: [],
          goals: null
        };
        
        setCurrentUser(user);
        return { success: true, user };
      }
    } catch (error: any) {
      console.error('❌ Email sign in failed:', error);
      
      // Firebase 에러 코드별 사용자 친화적 메시지 처리
      let userFriendlyMessage = 'Sign in failed';
      
      if (error.code) {
        switch (error.code) {
          case 'auth/invalid-credential':
            userFriendlyMessage = '이메일 또는 비밀번호가 올바르지 않습니다. 다시 확인해주세요.';
            break;
          case 'auth/user-not-found':
            userFriendlyMessage = '계정을 찾을 수 없습니다.';
            break;
          case 'auth/wrong-password':
            userFriendlyMessage = '비밀번호가 올바르지 않습니다.';
            break;
          case 'auth/invalid-email':
            userFriendlyMessage = '유효하지 않은 이메일입니다.';
            break;
          case 'auth/too-many-requests':
            userFriendlyMessage = '너무 많은 요청이 있었습니다. 잠시 후 다시 시도해주세요.';
            break;
          default:
            userFriendlyMessage = error.message || 'Sign in failed';
        }
      }
      
      return { 
        success: false, 
        error: userFriendlyMessage,
        code: error.code // 에러 코드도 함께 전달
      };
    }
  };

  const signUpWithEmail = async (email: string, password: string): Promise<AuthResult> => {
    try {
      if (isFirebaseAvailable && auth) {
        // Use Firebase Auth with detailed error logging
        console.log('🔍 Attempting Firebase createUserWithEmailAndPassword...');
        console.log(`📧 Email: ${email}`);
        console.log(`🔑 Auth instance:`, auth);
        
        const { createUserWithEmailAndPassword } = await import('firebase/auth');
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const firebaseUser = userCredential.user;
        
        // Don't create user object here - let onAuthStateChanged handle profile loading
        console.log('✅ Firebase email sign up successful - profile will be loaded by onAuthStateChanged');
        return { success: true, user: null }; // User will be set by onAuthStateChanged
      } else {
        // Mock authentication
        console.log('⚠️ Using mock email sign up');
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        const user: User = {
          uid: `mock-${Date.now()}`,
          email,
          displayName: 'New Mock User',
          photoURL: null,
          skillLevel: '1.0-2.5', // Beginner NTRP level
          playingStyle: 'all-court',
          maxTravelDistance: 15,
          location: {
            lat: 33.7490,
            lng: -84.3880,
            address: 'Atlanta, GA'
          },
          activityRegions: ['Atlanta Metro'],
          languages: ['English'],
          recentMatches: [],
          goals: null
        };
        
        setCurrentUser(user);
        return { success: true, user };
      }
    } catch (error: any) {
      console.error('❌ Email sign up failed:', error);
      console.error('🔍 Error details:');
      console.error(`   - Error code: ${error.code}`);
      console.error(`   - Error message: ${error.message}`);
      console.error(`   - Auth domain: ${process.env.EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN}`);
      console.error(`   - Project ID: ${process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID}`);
      
      // Firebase 에러 코드별 사용자 친화적 메시지 처리
      let userFriendlyMessage = 'Sign up failed';
      
      if (error.code) {
        switch (error.code) {
          case 'auth/email-already-in-use':
            userFriendlyMessage = '이미 사용 중인 이메일입니다.';
            break;
          case 'auth/weak-password':
            userFriendlyMessage = '비밀번호가 너무 약합니다. 6자 이상 입력해주세요.';
            break;
          case 'auth/invalid-email':
            userFriendlyMessage = '유효하지 않은 이메일입니다.';
            break;
          case 'auth/api-key-not-valid':
            userFriendlyMessage = 'API key configuration error. Please check Firebase Console settings.';
            break;
          case 'auth/invalid-api-key':
            userFriendlyMessage = 'Invalid API key. Please verify Firebase configuration.';
            break;
          case 'auth/app-not-authorized':
            userFriendlyMessage = 'App not authorized. Please check Bundle ID in Firebase Console.';
            break;
          default:
            userFriendlyMessage = error.message || 'Sign up failed';
        }
      }
      
      return { 
        success: false, 
        error: userFriendlyMessage,
        code: error.code // 에러 코드도 함께 전달
      };
    }
  };

  const signOut = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      setCurrentUser(null);
    } finally {
      setLoading(false);
    }
  };

  const updateUserProfile = async (updates: Partial<User>) => {
    if (!currentUser) {
      throw new Error('No current user to update');
    }

    try {
      // Update local state immediately for responsive UI
      const updatedUser = { ...currentUser, ...updates };
      
      // ✅ skillLevel과 ntrpLevel 동기화 (둘 중 하나가 변경되면 둘 다 같은 값으로 설정)
      if (updates.skillLevel && !updates.ntrpLevel) {
        updatedUser.ntrpLevel = updates.skillLevel;
      } else if (updates.ntrpLevel && !updates.skillLevel) {
        updatedUser.skillLevel = updates.ntrpLevel;
      }
      
      setCurrentUser(updatedUser);

      // Save to Firestore with nested profile structure
      if (isFirebaseAvailable && db) {
        const { doc, setDoc } = await import('firebase/firestore');
        const userDocRef = doc(db, 'users', currentUser.uid);
        
        // Create nested profile structure for Firestore
        const firestoreData = {
          uid: updatedUser.uid,
          email: updatedUser.email,
          profile: {
            nickname: updatedUser.displayName,
            photoURL: updatedUser.photoURL,
            skillLevel: updatedUser.skillLevel, // Unified NTRP skill level (e.g., '3.0-3.5')
            playingStyle: updatedUser.playingStyle,
            maxTravelDistance: updatedUser.maxTravelDistance,
            location: updatedUser.location,
            activityRegions: updatedUser.activityRegions,
            languages: updatedUser.languages,
            recentMatches: updatedUser.recentMatches,
            goals: updatedUser.goals
          },
          updatedAt: new Date()
        };
        
        await setDoc(userDocRef, firestoreData, { merge: true });
        console.log('✅ Profile successfully updated in Firestore');
        console.log('📊 Updated profile data:', firestoreData.profile);
      } else {
        console.warn('⚠️ Firebase not available, profile updated locally only');
      }
    } catch (error) {
      console.error('❌ Error updating user profile:', error);
      
      // Revert local state on Firestore error
      setCurrentUser(currentUser);
      
      // Re-throw error so EditProfileScreen can handle it
      throw new Error('Failed to update profile. Please try again.');
    }
  };

  const markOnboardingComplete = async (profileData?: Partial<User>) => {
    setIsOnboardingComplete(true);
    console.log('✅ AuthContext: Onboarding marked as complete');
    
    // Save onboarding completion to Firestore
    if (isFirebaseAvailable && db && currentUser) {
      try {
        const { doc, setDoc } = await import('firebase/firestore');
        const userDocRef = doc(db, 'users', currentUser.uid);
        
        // Merge profile data from onboarding with current user data
        const mergedUserData = profileData ? { ...currentUser, ...profileData } : currentUser;
        
        // Create nested profile structure for Firestore
        const firestoreData = {
          isOnboardingComplete: true,
          onboardingCompletedAt: new Date(),
          uid: mergedUserData.uid,
          email: mergedUserData.email,
          // Top-level user data for easier access
          displayName: mergedUserData.displayName, // Store displayName at top level too
          profile: {
            nickname: mergedUserData.displayName, // Store nickname in nested profile
            displayName: mergedUserData.displayName, // Also store in profile for redundancy
            photoURL: mergedUserData.photoURL,
            skillLevel: mergedUserData.skillLevel, // Unified NTRP skill level (e.g., '3.0-3.5')
            playingStyle: mergedUserData.playingStyle,
            maxTravelDistance: mergedUserData.maxTravelDistance,
            location: mergedUserData.location,
            activityRegions: mergedUserData.activityRegions,
            languages: mergedUserData.languages,
            recentMatches: mergedUserData.recentMatches,
            goals: mergedUserData.goals
          },
          updatedAt: new Date()
        };
        
        await setDoc(userDocRef, firestoreData, { merge: true });
        
        // Update local user state with merged data
        const finalUser = {
          ...mergedUserData,
          isOnboardingComplete: true
        };
        
        console.log('🔍 Final user data being set in AuthContext:');
        console.log('   - displayName:', finalUser.displayName);
        console.log('   - skillLevel:', finalUser.skillLevel);
        console.log('   - activityRegions:', finalUser.activityRegions);
        
        setCurrentUser(finalUser);
        setIsProfileLoaded(true); // ✅ 온보딩 완료 시 프로필 로딩도 완료
        
        console.log('💾 Complete onboarding data saved to Firestore with nested profile structure');
        console.log('📊 Saved profile data:', firestoreData.profile);
        console.log('✅ Onboarding complete - isProfileLoaded set to true');
      } catch (error) {
        console.error('❌ Error saving onboarding completion to Firestore:', error);
        // 에러가 발생해도 로컬 상태는 유지
      }
    } else {
      console.warn('⚠️ Firebase not available, onboarding completion only saved locally');
    }
  };

  const value: AuthContextType = {
    currentUser,
    loading,
    isProfileLoaded, // ✅ 새로운 상태 노출
    isOnboardingComplete,
    signIn,
    signInWithEmail,
    signUpWithEmail,
    signOut,
    updateUserProfile,
    markOnboardingComplete
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};