import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, Alert, RefreshControl, FlatList, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import clubService from '../services/clubService';
import AdminNotificationCard, { AdminNotification } from '../components/admin/AdminNotificationCard';

interface UserClub {
  id: string;
  clubId: string;
  clubName: string;
  role: 'admin' | 'manager' | 'member';
  status: 'pending' | 'active' | 'inactive';
  joinedAt: Date;
  memberCount?: number;
  clubDescription?: string;
  clubLocation?: string;
  clubLogo?: string;
  clubMaxMembers?: number;
  clubTags?: string[];
  clubContactInfo?: any;
  clubIsPublic?: boolean;
  clubEstablishedDate?: Date;
  pendingApplications?: number; // 가입 신청 개수
}

const MyClubsScreen = () => {
  const { currentLanguage } = useLanguage();
  const { currentUser: user, loading: authLoading } = useAuth();
  const navigation = useNavigation();
  
  const [userClubs, setUserClubs] = useState<UserClub[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [adminNotifications, setAdminNotifications] = useState<AdminNotification[]>([]);

  useEffect(() => {
    console.log('MyClubsScreen useEffect - user:', user);
    console.log('MyClubsScreen useEffect - authLoading:', authLoading);
    
    if (authLoading) {
      // 인증 로딩 중이면 대기
      console.log('Auth still loading, waiting...');
      return;
    }
    
    if (user?.uid) {
      console.log('User found with uid:', user.uid);
      loadUserClubs();
    } else if (user === null) {
      // 사용자가 로그인하지 않은 경우
      console.log('No user logged in, showing empty state');
      setUserClubs([]);
      setLoading(false);
    }
  }, [user, authLoading]);

  // 화면이 포커스될 때마다 클럽 목록 새로고침
  useFocusEffect(
    useCallback(() => {
      console.log('🔄 MyClubsScreen focused - refreshing club list');
      if (user?.uid && !authLoading) {
        loadUserClubs(true); // 포커스 시 강제 새로고침으로 최신 데이터 보장
      }
    }, [user?.uid, authLoading])
  );

  const loadUserClubs = async (forceRefresh = false) => {
    if (!user?.uid) {
      console.log('No user UID found, showing empty state');
      setUserClubs([]);
      setLoading(false);
      return;
    }
    
    try {
      setLoading(true);
      console.log('Loading clubs for user:', user.uid, forceRefresh ? '(force refresh)' : '');
      
      // 강제 새로고침 시 캐시 무시
      if (forceRefresh) {
        clubService.clearMembershipCache(user.uid);
      }
      
      // clubService에서 사용자의 클럽 멤버십 정보 가져오기
      console.log('🔍 Attempting to load clubs for user:', user.uid);
      console.log('🔍 User object:', user);
      
      const clubs = await clubService.getUserClubMemberships(user.uid);
      console.log('📋 Loaded clubs from service:', clubs);
      console.log('📋 Number of clubs found:', clubs.length);
      
      // 관리자 권한이 있는 클럽들의 가입 신청 개수 조회
      const clubsWithApplications = await Promise.all(
        clubs.map(async (club) => {
          // 관리자나 매니저 권한이 있는 경우만 가입 신청 개수 조회
          if (club.role === 'admin' || club.role === 'manager') {
            try {
              const applications = await clubService.getClubJoinRequests(club.clubId, 'pending');
              return {
                ...club,
                pendingApplications: applications.length
              };
            } catch (error) {
              console.warn(`Failed to load applications for club ${club.clubId}:`, error);
              return {
                ...club,
                pendingApplications: 0
              };
            }
          }
          return club;
        })
      );
      
      // 데이터가 없으면 mock 데이터 사용
      if (clubsWithApplications.length === 0) {
        console.warn('⚠️ No real clubs found for user, using mock data');
        console.log('🔍 This could be due to:');
        console.log('  - User has not created or joined any clubs yet');
        console.log('  - Firebase connection issues');
        console.log('  - Authentication problems');
        console.log('  - Database permission issues');
        
        // 실제 클럽 생성 여부 확인을 위한 추가 체크
        try {
          console.log('🔍 Attempting to check tennis_clubs collection for user-created clubs...');
          const userCreatedClubs = await clubService.checkUserCreatedClubs(user.uid);
          console.log('🔍 User created clubs check result:', userCreatedClubs);
        } catch (checkError) {
          console.error('❌ Failed to check user created clubs:', checkError);
        }
        // Use language-appropriate mock data
        const mockClubs = currentLanguage === 'ko' ? [
          {
            id: 'mock-membership-1',
            clubId: 'mock-club-1',
            clubName: '[샘플] 애틀랜타 둘루스 테니스 클럽',
            clubDescription: '주중 저녁·주말 오전 정기 랠리/매치가 있는 한인 테니스 동호회입니다.',
            clubLocation: '조지아주 둘루스 (Duluth, GA)',
            role: 'admin',
            status: 'active',
            joinedAt: new Date('2024-01-15'),
            memberCount: 120,
            clubTags: ['테니스', '동호회'],
            clubContactInfo: null,
            clubIsPublic: true,
            clubMaxMembers: 200,
            clubEstablishedDate: new Date('2023-01-01'),
            pendingApplications: 3, // Mock 가입 신청 3건
          },
          {
            id: 'mock-membership-2',
            clubId: 'mock-club-2', 
            clubName: '[샘플] 스와니 한인 테니스 클럽',
            clubDescription: '스와니·슈거힐·버퍼드 인근 한인 테니스 모임입니다!',
            clubLocation: '조지아주 스와니 (Suwanee, GA)',
            role: 'member',
            status: 'active',
            joinedAt: new Date('2024-02-01'),
            memberCount: 85,
            clubTags: ['테니스', '한인'],
            clubContactInfo: null,
            clubIsPublic: true,
            clubMaxMembers: 150,
            clubEstablishedDate: new Date('2023-06-01'),
            pendingApplications: 0, // Member 역할은 가입 신청 조회 불가
          },
        ] : [
          {
            id: 'mock-membership-1',
            clubId: 'mock-club-1',
            clubName: '[Sample] Atlanta Duluth Tennis Club',
            clubDescription: 'Weekly evening rallies and weekend morning matches for Korean-American tennis community.',
            clubLocation: 'Duluth, GA',
            role: 'admin',
            status: 'active',
            joinedAt: new Date('2024-01-15'),
            memberCount: 120,
            clubTags: ['Tennis', 'Community'],
            clubContactInfo: null,
            clubIsPublic: true,
            clubMaxMembers: 200,
            clubEstablishedDate: new Date('2023-01-01'),
            pendingApplications: 3, // Mock pending applications
          },
          {
            id: 'mock-membership-2',
            clubId: 'mock-club-2', 
            clubName: '[Sample] Suwanee Korean Tennis Club',
            clubDescription: 'Tennis group for Suwanee, Sugar Hill, and Buford area Korean community!',
            clubLocation: 'Suwanee, GA',
            role: 'member',
            status: 'active',
            joinedAt: new Date('2024-02-01'),
            memberCount: 85,
            clubTags: ['Tennis', 'Korean'],
            clubContactInfo: null,
            clubIsPublic: true,
            clubMaxMembers: 150,
            clubEstablishedDate: new Date('2023-06-01'),
            pendingApplications: 0, // Member role cannot see applications
          },
        ];
        setUserClubs(mockClubs);
        setAdminNotifications(generateAdminNotifications(mockClubs));
      } else {
        setUserClubs(clubsWithApplications);
        setAdminNotifications(generateAdminNotifications(clubsWithApplications));
      }
    } catch (error) {
      console.error('❌ Error loading user clubs:', error);
      console.error('❌ Error details:', {
        message: error.message,
        code: error.code,
        stack: error.stack
      });
      
      // Firebase 연결 문제나 권한 문제 시 mock 데이터로 fallback
      console.warn('⚠️ Using mock data as fallback due to error');
      console.log('🔍 Error type analysis:');
      if (error.message?.includes('permission') || error.code?.includes('permission')) {
        console.log('  - Firebase permission denied');
      } else if (error.message?.includes('network') || error.code?.includes('network')) {
        console.log('  - Network connection issue');
      } else if (error.message?.includes('auth') || error.code?.includes('auth')) {
        console.log('  - Authentication issue');
      } else {
        console.log('  - Unknown error type');
      }
      // Use language-appropriate mock data for error fallback
      const fallbackMockClubs = currentLanguage === 'ko' ? [
        {
          id: 'mock-membership-1',
          clubId: 'mock-club-1',
          clubName: '[샘플] 애틀랜타 둘루스 테니스 클럽',
          clubDescription: '주중 저녁·주말 오전 정기 랠리/매치가 있는 한인 테니스 동호회입니다.',
          clubLocation: '조지아주 둘루스 (Duluth, GA)',
          role: 'admin',
          status: 'active',
          joinedAt: new Date('2024-01-15'),
          memberCount: 120,
          clubTags: ['한인', '테니스'],
          clubContactInfo: null,
          clubIsPublic: true,
          clubMaxMembers: 200,
          clubEstablishedDate: new Date('2023-06-01'),
        }
      ] : [
        {
          id: 'mock-membership-1',
          clubId: 'mock-club-1',
          clubName: '[Sample] Atlanta Duluth Tennis Club',
          clubDescription: 'Weekly evening rallies and weekend morning matches for Korean-American tennis community.',
          clubLocation: 'Duluth, GA',
          role: 'admin',
          status: 'active',
          joinedAt: new Date('2024-01-15'),
          memberCount: 120,
          clubTags: ['Korean', 'Tennis'],
          clubContactInfo: null,
          clubIsPublic: true,
          clubMaxMembers: 200,
          clubEstablishedDate: new Date('2023-06-01'),
          pendingApplications: 3, // Fallback mock applications
        }
      ];
      setUserClubs(fallbackMockClubs);
      setAdminNotifications(generateAdminNotifications(fallbackMockClubs));
    } finally {
      setLoading(false);
    }
  };

  // 관리자 알림 생성 함수
  const generateAdminNotifications = (clubs: UserClub[]): AdminNotification[] => {
    const notifications: AdminNotification[] = [];
    
    clubs.forEach(club => {
      if ((club.role === 'admin' || club.role === 'manager') && club.pendingApplications && club.pendingApplications > 0) {
        notifications.push({
          id: `club_applications_${club.clubId}`,
          type: 'club_applications',
          clubId: club.clubId,
          clubName: club.clubName,
          count: club.pendingApplications,
          priority: club.pendingApplications > 5 ? 'high' : club.pendingApplications > 2 ? 'medium' : 'low',
          title: '새로운 가입 신청',
          description: `${club.pendingApplications}건의 클럽 가입 신청이 대기 중입니다.`,
          actionRequired: true,
          createdAt: new Date(),
          data: {
            targetTab: 1 // 멤버 탭으로 이동
          }
        });
      }
    });
    
    return notifications;
  };

  // 알림 카드 클릭 핸들러
  const handleNotificationPress = (notification: AdminNotification) => {
    navigation.navigate('ClubDetail', {
      clubId: notification.clubId,
      userRole: 'admin',
      initialTab: notification.data?.targetTab || 1
    });
  };

  // 알림 해제 핸들러
  const handleNotificationDismiss = (notificationId: string) => {
    setAdminNotifications(prev => prev.filter(n => n.id !== notificationId));
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadUserClubs(true); // 강제 새로고침으로 캐시 무시
    setRefreshing(false);
  };

  const handleClubPress = (club: UserClub) => {
    // 가입 신청이 있는 관리자/매니저의 경우 멤버 탭으로 이동
    if ((club.role === 'admin' || club.role === 'manager') && club.pendingApplications && club.pendingApplications > 0) {
      navigation.navigate('ClubDetail', { 
        clubId: club.clubId,
        userRole: club.role,
        initialTab: 1 // 멤버 탭 (0: 홈, 1: 멤버, 2: 이벤트, 3: 리그, 4: 정책, 5: 게시판, 6: 채팅)
      });
    } else {
      navigation.navigate('ClubDetail', { 
        clubId: club.clubId,
        userRole: club.role 
      });
    }
  };

  const handleDiscoverClubs = () => {
    navigation.navigate('MainTabs', { screen: 'Discover' });
  };

  const handleCreateClub = () => {
    navigation.navigate('CreateClub');
  };


  const handleFindClubs = () => {
    navigation.navigate('FindClub');
  };

  const getRoleText = (role: string) => {
    if (currentLanguage === 'ko') {
      switch (role) {
        case 'admin': return '관리자';
        case 'manager': return '매니저';
        case 'member': return '멤버';
        default: return '멤버';
      }
    } else {
      switch (role) {
        case 'admin': return 'Admin';
        case 'manager': return 'Manager';
        case 'member': return 'Member';
        default: return 'Member';
      }
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return '#f44336';
      case 'manager': return '#ff9800';
      default: return '#4caf50';
    }
  };

  const renderClubItem = ({ item: club }: { item: UserClub }) => (
    <TouchableOpacity 
      style={styles.clubCard}
      onPress={() => handleClubPress(club)}
      activeOpacity={0.7}
    >
      <View style={styles.clubCardContent}>
        {/* Club Logo/Image */}
        <View style={styles.clubLogoContainer}>
          {club.clubLogo ? (
            <Image source={{ uri: club.clubLogo }} style={styles.clubLogo} />
          ) : (
            <View style={styles.clubLogoPlaceholder}>
              <Ionicons name="basketball" size={28} color="#fff" />
            </View>
          )}
        </View>
        
        {/* Club Info */}
        <View style={styles.clubInfoContainer}>
          <View style={styles.clubHeader}>
            <Text style={styles.clubName} numberOfLines={1}>{club.clubName}</Text>
            <View style={styles.clubBadges}>
              <View style={[styles.roleChip, { backgroundColor: getRoleColor(club.role) }]}>
                <Text style={styles.roleText}>{getRoleText(club.role)}</Text>
              </View>
              {/* 가입 신청 알림 뱃지 */}
              {(club.role === 'admin' || club.role === 'manager') && club.pendingApplications && club.pendingApplications > 0 && (
                <View style={styles.applicationBadge}>
                  <Ionicons name="person-add" size={12} color="#fff" />
                  <Text style={styles.applicationBadgeText}>{club.pendingApplications}</Text>
                </View>
              )}
            </View>
          </View>
          
          {club.clubDescription && (
            <Text style={styles.clubDescription} numberOfLines={2}>
              {club.clubDescription}
            </Text>
          )}
          
          <View style={styles.clubMetaContainer}>
            <View style={styles.clubMetaRow}>
              <Ionicons name="location-outline" size={14} color="#666" />
              <Text style={styles.clubMetaText}>{club.clubLocation || 'Unknown'}</Text>
            </View>
            <View style={styles.clubMetaRow}>
              <Ionicons name="people-outline" size={14} color="#666" />
              <Text style={styles.clubMetaText}>
                {`${club.memberCount || 0}${club.clubMaxMembers ? `/${club.clubMaxMembers}` : ''}${currentLanguage === 'ko' ? ' 명' : ''}`}
              </Text>
            </View>
          </View>
        </View>
        
        {/* Arrow */}
        <Ionicons name="chevron-forward" size={20} color="#999" style={styles.chevron} />
      </View>
    </TouchableOpacity>
  );

  if (authLoading || loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>🏟️ {currentLanguage === 'ko' ? '내 클럽' : 'My Clubs'}</Text>
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#1976d2" />
          <Text style={styles.loadingText}>
            {authLoading 
              ? (currentLanguage === 'ko' ? '로그인 정보 확인 중...' : 'Checking login...')
              : (currentLanguage === 'ko' ? '클럽 정보를 불러오는 중...' : 'Loading clubs...')
            }
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>🏟️ {currentLanguage === 'ko' ? '내 클럽' : 'My Clubs'}</Text>
        <View style={styles.headerButtons}>
          <TouchableOpacity style={styles.headerButton} onPress={handleFindClubs}>
            <Ionicons name="search" size={24} color="#1976d2" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.headerButton} onPress={handleCreateClub}>
            <Ionicons name="add" size={24} color="#1976d2" />
          </TouchableOpacity>
        </View>
      </View>
      
      <ScrollView 
        style={styles.content}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {userClubs.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>🎾</Text>
            <Text style={styles.emptyTitle}>
              {currentLanguage === 'ko' ? '가입한 클럽이 없습니다' : 'No clubs joined yet'}
            </Text>
            <Text style={styles.emptyDescription}>
              {currentLanguage === 'ko' 
                ? '발견 탭에서 클럽을 찾아 가입해보거나\n새로운 클럽을 만들어보세요' 
                : 'Find clubs to join in the Discover tab\nor create your own club'}
            </Text>
            
            <View style={styles.emptyActions}>
              <TouchableOpacity style={styles.discoverButton} onPress={handleDiscoverClubs}>
                <Text style={styles.discoverButtonText}>
                  {currentLanguage === 'ko' ? '클럽 찾아보기' : 'Find Clubs'}
                </Text>
                <Ionicons name="search" size={20} color="#1976d2" />
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.createClubButton} onPress={handleCreateClub}>
                <Text style={styles.createClubButtonText}>
                  {currentLanguage === 'ko' ? '클럽 만들기' : 'Create Club'}
                </Text>
                <Ionicons name="add" size={20} color="#fff" />
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <>
            {/* 관리자 알림 카드들 */}
            {adminNotifications.length > 0 && (
              <View style={styles.notificationsSection}>
                {adminNotifications.map((notification) => (
                  <AdminNotificationCard
                    key={notification.id}
                    notification={notification}
                    onPress={() => handleNotificationPress(notification)}
                    onDismiss={() => handleNotificationDismiss(notification.id)}
                  />
                ))}
              </View>
            )}
            
            <FlatList
              data={userClubs}
              renderItem={renderClubItem}
              keyExtractor={(item) => item.id}
              contentContainerStyle={styles.clubsList}
              scrollEnabled={false}
            />
            
            {/* Create New Club 버튼 */}
            <TouchableOpacity style={styles.createNewClubCard} onPress={handleCreateClub}>
              <View style={styles.createNewClubContent}>
                <View style={styles.createIconContainer}>
                  <Ionicons name="add-circle" size={32} color="#1976d2" />
                </View>
                <View style={styles.createInfoContainer}>
                  <Text style={styles.createTitle}>
                    {currentLanguage === 'ko' ? '새 클럽 만들기' : 'Create New Club'}
                  </Text>
                  <Text style={styles.createDescription}>
                    {currentLanguage === 'ko' 
                      ? '나만의 테니스 클럽을 시작해보세요' 
                      : 'Start your own tennis club'}
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#1976d2" />
              </View>
            </TouchableOpacity>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  content: {
    flex: 1,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 100,
  },
  emptyIcon: {
    fontSize: 60,
    marginBottom: 20,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 10,
  },
  emptyDescription: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    paddingHorizontal: 40,
    lineHeight: 20,
    marginBottom: 30,
  },
  emptyActions: {
    flexDirection: 'row',
    gap: 12,
  },
  discoverButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#e3f2fd',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 25,
  },
  discoverButtonText: {
    fontSize: 16,
    color: '#1976d2',
    fontWeight: '600',
    marginRight: 8,
  },
  createClubButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1976d2',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 25,
  },
  createClubButtonText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: '600',
    marginRight: 8,
  },
  headerButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  headerButton: {
    padding: 8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#666',
    marginTop: 16,
  },
  clubsList: {
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  clubCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 3,
  },
  clubCardContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  clubLogoContainer: {
    marginRight: 12,
  },
  clubLogo: {
    width: 56,
    height: 56,
    borderRadius: 28,
  },
  clubLogoPlaceholder: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#1976d2',
    justifyContent: 'center',
    alignItems: 'center',
  },
  clubInfoContainer: {
    flex: 1,
  },
  clubHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  clubName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    flex: 1,
    marginRight: 8,
  },
  clubDescription: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
    lineHeight: 18,
  },
  clubMetaContainer: {
    flexDirection: 'row',
    gap: 16,
  },
  clubMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  clubMetaText: {
    fontSize: 12,
    color: '#666',
    marginLeft: 4,
  },
  roleChip: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  roleText: {
    fontSize: 11,
    color: '#fff',
    fontWeight: '600',
  },
  chevron: {
    marginLeft: 8,
  },
  createNewClubCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginHorizontal: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#1976d2',
    borderStyle: 'dashed',
  },
  createNewClubContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  createIconContainer: {
    marginRight: 12,
  },
  createInfoContainer: {
    flex: 1,
  },
  createTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1976d2',
    marginBottom: 4,
  },
  createDescription: {
    fontSize: 14,
    color: '#666',
  },
  // 클럽 카드 뱃지 관련 스타일
  clubBadges: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  applicationBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ff5722',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    gap: 4,
  },
  applicationBadgeText: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#fff',
  },
  // 알림 섹션 스타일
  notificationsSection: {
    marginBottom: 16,
  },
});


// Export the full functional component
export default MyClubsScreen;