import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import ntrpEn from './ntrp.en.json';
import ntrpKo from './ntrp.ko.json';

// Robust localization module detection
let ExpoLocalization: any = null;
let RNLocalize: any = null;

try {
  // Try Expo Localization first (for Expo projects)
  ExpoLocalization = require('expo-localization');
} catch (e) {
  try {
    // Fallback to react-native-localize (for bare React Native)
    RNLocalize = require('react-native-localize');
  } catch (e2) {
    console.warn('No localization module found, using fallback');
  }
}

export const resources = {
  en: {
    translation: {
      common: {
        submit: "Submit",
        required: "Required",
      },
      createClub: {
        // 큰 페이지 타이틀은 화면에서 제거되지만, 앱바 타이틀 등에서 사용할 수 있음
        title: "Create Club",
        basic_info: "Basic Info",
        court_address: "Court Address",
        regular_meet: "Recurring Meetups",
        visibility: "Visibility",
        visibility_public: "Public",
        visibility_private: "Private",
        fees: "Fees",
        facilities: "Facilities",
        rules: "Club Rules",
        loading: "Loading club information...",
        address_search_title: "Search Tennis Court Address",
        meeting_modal_title: "Add Regular Meeting Time",
        day_selection: "Day Selection",
        meeting_time: "Meeting Time",
        start_time: "Start Time",
        end_time: "End Time",
        add_meeting: "Add Meeting Time",
        cancel: "Cancel",
        add: "Add",
        creating: "Creating...",
        errors: {
          address_required: "Address is required.",
        },
        facility: {
          lights: "Lights",
          indoor: "Indoor",
          parking: "Parking",
          ballmachine: "Ball Machine",
          locker: "Locker Room",
          proshop: "Pro Shop",
        },
        fields: {
          name: "Club Name",
          intro: "Introduction",
          address_placeholder: "Search court address (EN/US/Atlanta bias)",
          address_label: "Tennis Court Address",
          address_search_placeholder: "Search for tennis court address",
          name_placeholder: "e.g., Duluth Korean Tennis Club",
          intro_placeholder: "Describe your club's goals, atmosphere, and unique features",
          fee_placeholder: "e.g., 50",
          rules_placeholder: "e.g.:\n• Maintain 70%+ attendance for regular meetings\n• Show mutual respect and courtesy\n• Clean up after using facilities",
          meet_day: "Day",
          meet_time: "Time",
          meet_note: "Note",
          fee: "Membership Fee",
          rules: "Rules / Etiquette",
          logo: "Logo",
        },
        cta: "Create Club",
        hints: {
          public_club: "Public clubs allow other users to search and apply for membership.",
        },
      },
      ntrp: (ntrpEn as any).ntrp
    }
  },
  ko: {
    translation: {
      common: {
        submit: "제출",
        required: "필수",
      },
      createClub: {
        title: "클럽 만들기",
        basic_info: "기본 정보",
        court_address: "코트 주소",
        regular_meet: "정기 모임",
        visibility: "공개 설정",
        visibility_public: "공개",
        visibility_private: "비공개",
        fees: "비용 정보",
        facilities: "시설 정보",
        rules: "클럽 규칙",
        loading: "클럽 정보를 불러오는 중...",
        address_search_title: "테니스 코트 주소 검색",
        meeting_modal_title: "정기 모임 시간 추가",
        day_selection: "요일 선택",
        meeting_time: "모임 시간",
        start_time: "시작 시간",
        end_time: "종료 시간",
        add_meeting: "정기 모임 시간 추가",
        cancel: "취소",
        add: "추가",
        creating: "만드는 중…",
        errors: {
          address_required: "주소가 필요합니다",
        },
        facility: {
          lights: "야간 조명",
          indoor: "실내 코트",
          parking: "주차장",
          ballmachine: "볼머신",
          locker: "락커룸",
          proshop: "프로샵",
        },
        fields: {
          name: "클럽 이름",
          intro: "소개",
          address_placeholder: "코트 주소 검색 (영어/미국/애틀랜타 우선)",
          address_label: "테니스 코트 주소",
          address_search_placeholder: "테니스 코트 주소를 검색하세요",
          name_placeholder: "예: 둘루스 한인 테니스 클럽",
          intro_placeholder: "아틀란타 메트로 한인 테니스 클럽의 목표, 분위기, 특징 등을 소개해주세요",
          fee_placeholder: "예: 50",
          rules_placeholder: "예:\n• 정기 모임 참석률 70% 이상 유지\n• 상호 예의와 배려\n• 시설 이용 후 정리정돈",
          meet_day: "요일",
          meet_time: "시간",
          meet_note: "비고",
          fee: "회비",
          rules: "규칙 / 에티켓",
          logo: "로고",
        },
        cta: "클럽 만들기",
        hints: {
          public_club: "공개 클럽은 다른 사용자가 검색하고 가입 신청할 수 있습니다.",
        },
      },
      ntrp: (ntrpKo as any).ntrp
    }
  }
};

const languageDetector = {
  type: 'languageDetector' as const,
  async: true,
  detect: (callback: (lng: string) => void) => {
    try {
      // Try Expo Localization first
      if (ExpoLocalization && typeof ExpoLocalization.getLocales === 'function') {
        const locales = ExpoLocalization.getLocales();
        if (locales && locales.length > 0 && locales[0].languageCode) {
          const lang = locales[0].languageCode;
          callback(['ko', 'kr'].includes(lang) ? 'ko' : 'en');
          return;
        }
      }
      
      // Fallback to react-native-localize
      if (RNLocalize && typeof RNLocalize.getLocales === 'function') {
        const locales = RNLocalize.getLocales();
        if (locales && locales.length > 0 && locales[0].languageCode) {
          const lang = locales[0].languageCode;
          callback(['ko', 'kr'].includes(lang) ? 'ko' : 'en');
          return;
        }
      }
    } catch (e) {
      console.warn('Language detection error:', e);
    }
    
    // Ultimate fallback to English
    callback('en');
  },
  init: () => {},
  cacheUserLanguage: () => {},
};

i18n
  .use(languageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'en',
    debug: __DEV__,
    interpolation: {
      escapeValue: false,
    },
  });

export default i18n;