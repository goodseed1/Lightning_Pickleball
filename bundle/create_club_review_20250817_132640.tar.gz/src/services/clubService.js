/**
 * Club Management Service for Lightning Tennis
 * Handles all club-related operations including creation, membership, events, and chat
 */

import {
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  onSnapshot,
  serverTimestamp,
  increment,
  arrayUnion,
  arrayRemove,
  writeBatch,
  runTransaction
} from 'firebase/firestore';
import { db } from '../firebase/config';
import authService from './authService';

/**
 * Club Service Class
 * Manages all club-related database operations
 */
class ClubService {
  constructor() {
    console.log('🏟️ ClubService initialized');
  }

  // ============ CLUB MANAGEMENT ============

  /**
   * Create a new tennis club
   * @param {Object} clubData - Club information
   * @returns {Promise<string>} Created club ID
   */
  async createClub(clubData) {
    try {
      console.log('🎾 Creating club with data:', clubData);
      
      // Try to get current user, fallback to mock if auth service unavailable
      let currentUser;
      try {
        currentUser = authService.getCurrentUser();
      } catch (authError) {
        console.warn('⚠️ Auth service unavailable, using mock user');
        currentUser = { uid: clubData.createdBy || 'mock-user-id' };
      }
      
      if (!currentUser) {
        throw new Error('User must be authenticated');
      }

      // Try Firebase, fallback to mock if unavailable
      try {
        const clubsRef = collection(db, 'tennis_clubs');
        
        // Prepare club document with simplified structure
        const clubDoc = {
          profile: {
            name: clubData.name,
            description: clubData.description,
            logo: clubData.logoUri || null,
            coverImage: null,
            location: clubData.region,
            establishedDate: serverTimestamp(),
            tags: [],
            contactInfo: null,
            socialLinks: null,
            facilities: clubData.facilities || [],
            rules: clubData.rules || [],
            courtAddress: clubData.courtAddress || null
          },
          settings: {
            isPublic: clubData.isPublic,
            joinRequiresApproval: true,
            membershipFee: clubData.monthlyFee || 0,
            joinFee: clubData.joinFee || 0,
            maxMembers: 100,
            meetings: clubData.meetings || []
          },
          statistics: {
            totalMembers: 1,
            activeMembers: 1,
            eventsHosted: 0,
            matchesPlayed: 0
          },
          createdBy: currentUser.uid,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
          status: 'active'
        };

        // Create club and add creator as admin in a transaction
        const result = await runTransaction(db, async (transaction) => {
          // Create club document
          const newClubRef = doc(clubsRef);
          transaction.set(newClubRef, clubDoc);

          // Add creator as club admin
          const membershipId = `${newClubRef.id}_${currentUser.uid}`;
          const memberRef = doc(db, 'clubMembers', membershipId);
          
          const memberDoc = {
            clubId: newClubRef.id,
            userId: currentUser.uid,
            role: 'admin',
            status: 'active',
            joinedAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          };

          transaction.set(memberRef, memberDoc);

          return newClubRef.id;
        });

        console.log('✅ Club created successfully with Firebase:', result);
        return result;

      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable, using mock creation:', firebaseError.message);
        
        // Mock implementation
        const mockClubId = `club_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        // Simulate async operation
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        console.log('✅ Mock club created with ID:', mockClubId);
        return mockClubId;
      }

    } catch (error) {
      console.error('❌ Failed to create club:', error);
      throw new Error('클럽 생성 중 오류가 발생했습니다: ' + error.message);
    }
  }

  /**
   * Update existing tennis club
   * @param {string} clubId - Club ID to update
   * @param {Object} clubData - Updated club information
   * @returns {Promise<void>}
   */
  async updateClub(clubId, clubData) {
    try {
      console.log('🔄 Updating club:', clubId, 'with data:', clubData);
      
      // Try to get current user
      let currentUser;
      try {
        currentUser = authService.getCurrentUser();
      } catch (authError) {
        console.warn('⚠️ Auth service unavailable, using mock user');
        currentUser = { uid: 'mock-user-id' };
      }
      
      if (!currentUser) {
        throw new Error('User must be authenticated');
      }

      // Try Firebase, fallback to mock if unavailable
      try {
        const clubRef = doc(db, 'tennis_clubs', clubId);
        
        // Prepare updated club document
        const updateData = {
          'profile.name': clubData.name,
          'profile.description': clubData.description,
          'profile.logo': clubData.logoUri || null,
          'profile.location': clubData.region,
          'profile.facilities': clubData.facilities || [],
          'profile.rules': clubData.rules || [],
          'profile.courtAddress': clubData.courtAddress || null,
          'settings.isPublic': clubData.isPublic,
          'settings.membershipFee': clubData.monthlyFee || 0,
          'settings.joinFee': clubData.joinFee || 0,
          'settings.meetings': clubData.meetings || [],
          updatedAt: serverTimestamp()
        };

        await updateDoc(clubRef, updateData);
        console.log('✅ Club updated successfully');
        
        return true;
      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable, mock update:', firebaseError.message);
        
        // Mock success for testing
        console.log('✅ Mock club update completed');
        return true;
      }

    } catch (error) {
      console.error('❌ Failed to update club:', error);
      throw new Error('클럽 수정 중 오류가 발생했습니다: ' + error.message);
    }
  }

  /**
   * Get club by ID
   * @param {string} clubId - Club ID
   * @returns {Promise<Object>} Club data
   */
  async getClub(clubId) {
    try {
      const clubRef = doc(db, 'clubs', clubId);
      const clubSnap = await getDoc(clubRef);

      if (!clubSnap.exists()) {
        throw new Error('Club not found');
      }

      const clubData = { id: clubSnap.id, ...clubSnap.data() };
      console.log('✅ Club retrieved:', clubData.name);
      return clubData;
    } catch (error) {
      console.error('❌ Failed to get club:', error);
      throw error;
    }
  }

  /**
   * Search public clubs with text query
   * @param {string} query - Search query
   * @param {number} limitCount - Results limit
   * @returns {Promise<Array>} Array of public clubs
   */
  async searchPublicClubs(query = '', limitCount = 50) {
    try {
      console.log('🔍 Searching public clubs with query:', query);
      
      // Try Firebase first
      try {
        const clubsRef = collection(db, 'tennis_clubs');
        let q = query(
          clubsRef,
          where('status', '==', 'active'),
          where('settings.isPublic', '==', true),
          limit(limitCount)
        );

        const snapshot = await getDocs(q);
        let clubs = snapshot.docs.map(doc => {
          const data = doc.data();
          return {
            id: doc.id,
            name: data.profile?.name || data.name || 'Unknown Club',
            description: data.profile?.description || data.description || '',
            location: data.profile?.location || data.location || 'Unknown Location',
            logoUrl: data.profile?.logo || data.logoUrl,
            memberCount: data.statistics?.totalMembers || 0,
            maxMembers: data.settings?.maxMembers || 100,
            isPublic: data.settings?.isPublic ?? true,
            tags: data.profile?.tags || data.tags || [],
            establishedDate: data.profile?.establishedDate?.toDate() || data.establishedDate?.toDate(),
          };
        });

        // Client-side filtering for text search (Firebase doesn't have full-text search)
        if (query.trim()) {
          const searchQuery = query.toLowerCase();
          clubs = clubs.filter(club => 
            club.name.toLowerCase().includes(searchQuery) ||
            club.location.toLowerCase().includes(searchQuery) ||
            club.description.toLowerCase().includes(searchQuery) ||
            club.tags.some(tag => tag.toLowerCase().includes(searchQuery))
          );
        }

        console.log(`✅ Found ${clubs.length} public clubs from Firebase`);
        return clubs;
        
      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable, using mock data:', firebaseError.message);
        
        // Return mock data for testing
        const mockClubs = [
          {
            id: 'mock-public-club-1',
            name: '서울 중앙 테니스 클럽',
            description: '서울 중심가에서 활동하는 다양한 레벨의 테니스 동호회입니다.',
            location: '서울시 강남구',
            logoUrl: null,
            memberCount: 45,
            maxMembers: 60,
            isPublic: true,
            tags: ['테니스', '동호회', '강남'],
            establishedDate: new Date('2023-01-01'),
          },
          {
            id: 'mock-public-club-2',
            name: '부산 해운대 테니스 클럽',
            description: '해변에서 즐기는 테니스의 매력을 느껴보세요.',
            location: '부산시 해운대구',
            logoUrl: null,
            memberCount: 28,
            maxMembers: 40,
            isPublic: true,
            tags: ['테니스', '해변', '부산'],
            establishedDate: new Date('2023-06-01'),
          },
          {
            id: 'mock-public-club-3',
            name: '대전 유성 테니스 클럽',
            description: '과학도시 대전에서 함께하는 테니스 커뮤니티입니다.',
            location: '대전시 유성구',
            logoUrl: null,
            memberCount: 32,
            maxMembers: 50,
            isPublic: true,
            tags: ['테니스', '유성', '대전'],
            establishedDate: new Date('2023-03-15'),
          },
        ];

        // Apply client-side filtering for mock data too
        if (query.trim()) {
          const searchQuery = query.toLowerCase();
          return mockClubs.filter(club => 
            club.name.toLowerCase().includes(searchQuery) ||
            club.location.toLowerCase().includes(searchQuery) ||
            club.description.toLowerCase().includes(searchQuery) ||
            club.tags.some(tag => tag.toLowerCase().includes(searchQuery))
          );
        }
        
        return mockClubs;
      }
    } catch (error) {
      console.error('❌ Failed to search public clubs:', error);
      throw error;
    }
  }

  /**
   * Get user's status for a specific club
   * @param {string} clubId - Club ID
   * @param {string} userId - User ID
   * @returns {Promise<string>} User status: 'none', 'member', 'pending', 'declined'
   */
  async getUserClubStatus(clubId, userId) {
    try {
      // Check if user is a member
      const membershipId = `${clubId}_${userId}`;
      const memberRef = doc(db, 'clubMembers', membershipId);
      
      try {
        const memberSnap = await getDoc(memberRef);
        if (memberSnap.exists()) {
          const memberData = memberSnap.data();
          return memberData.status === 'active' ? 'member' : memberData.status;
        }
      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable for membership check');
      }

      // Check join requests
      const requestsRef = collection(db, 'clubJoinRequests');
      const requestQuery = query(
        requestsRef,
        where('clubId', '==', clubId),
        where('userId', '==', userId),
        orderBy('requestedAt', 'desc'),
        limit(1)
      );

      try {
        const requestSnap = await getDocs(requestQuery);
        if (!requestSnap.empty) {
          const requestData = requestSnap.docs[0].data();
          return requestData.status; // 'pending', 'approved', 'declined'
        }
      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable for join request check');
      }

      return 'none';
    } catch (error) {
      console.error('❌ Failed to get user club status:', error);
      return 'none';
    }
  }

  /**
   * Request to join a club
   * @param {string} clubId - Club ID
   * @param {string} userId - User ID
   * @returns {Promise<string>} Request ID
   */
  async requestToJoinClub(clubId, userId) {
    try {
      console.log('📝 Creating join request:', { clubId, userId });
      
      // Try to get current user info
      let currentUser;
      try {
        currentUser = authService.getCurrentUser();
      } catch (authError) {
        console.warn('⚠️ Auth service unavailable, proceeding with join request');
        currentUser = { uid: userId };
      }
      
      if (!currentUser || currentUser.uid !== userId) {
        throw new Error('User must be authenticated');
      }

      // Try Firebase creation
      try {
        const requestsRef = collection(db, 'clubJoinRequests');
        const requestDoc = {
          clubId,
          userId,
          status: 'pending',
          requestedAt: serverTimestamp(),
          message: '', // Optional message from user
        };

        const docRef = await addDoc(requestsRef, requestDoc);
        
        console.log('✅ Join request created successfully in Firebase:', docRef.id);
        return docRef.id;
        
      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable, using mock join request:', firebaseError.message);
        
        // Simulate async operation
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        const mockRequestId = `mock-request-${Date.now()}`;
        console.log('✅ Mock join request created:', mockRequestId);
        return mockRequestId;
      }
    } catch (error) {
      console.error('❌ Failed to request to join club:', error);
      throw new Error('클럽 가입 신청 중 오류가 발생했습니다: ' + error.message);
    }
  }

  /**
   * Get join requests for a club
   * @param {string} clubId - Club ID
   * @param {string} status - Request status filter ('pending', 'approved', 'declined')
   * @returns {Promise<Array>} Array of join requests with user details
   */
  async getClubJoinRequests(clubId, status = 'pending') {
    try {
      console.log('🔍 Getting join requests for club:', clubId, 'with status:', status);
      
      // Try Firebase first
      try {
        const requestsRef = collection(db, 'clubJoinRequests');
        const q = query(
          requestsRef,
          where('clubId', '==', clubId),
          where('status', '==', status),
          orderBy('requestedAt', 'desc')
        );

        const querySnapshot = await getDocs(q);
        const requests = [];

        for (const docSnap of querySnapshot.docs) {
          const requestData = docSnap.data();
          
          // Get user information
          let userInfo = null;
          try {
            const userDoc = await getDoc(doc(db, 'users', requestData.userId));
            if (userDoc.exists()) {
              userInfo = userDoc.data();
            }
          } catch (userError) {
            console.error('Error fetching user data:', userError);
          }

          requests.push({
            id: docSnap.id,
            clubId: requestData.clubId,
            userId: requestData.userId,
            userName: userInfo?.profile?.nickname || 
                     userInfo?.displayName ||
                     'Unknown User',
            profileImage: userInfo?.profile?.photoURL || userInfo?.photoURL,
            skillLevel: userInfo?.profile?.skillLevel,
            status: requestData.status,
            requestedAt: requestData.requestedAt?.toDate() || new Date(),
            message: requestData.message || '',
          });
        }

        console.log(`✅ Found ${requests.length} join requests from Firebase`);
        return requests;
        
      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable, using mock data:', firebaseError.message);
        
        // Return mock data for testing
        if (status === 'pending') {
          return [
            {
              id: 'mock-request-1',
              clubId,
              userId: 'user-request-1',
              userName: '김신청자',
              profileImage: null,
              skillLevel: 3.5,
              status: 'pending',
              requestedAt: new Date(),
              message: '테니스를 좋아하는 직장인입니다. 함께 운동하고 싶어요!',
            },
            {
              id: 'mock-request-2',
              clubId,
              userId: 'user-request-2',
              userName: '이희망자',
              profileImage: null,
              skillLevel: 4.0,
              status: 'pending',
              requestedAt: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
              message: '',
            },
          ];
        }
        
        return [];
      }
    } catch (error) {
      console.error('❌ Failed to get club join requests:', error);
      throw error;
    }
  }

  /**
   * Approve join request
   * @param {string} requestId - Join request ID
   * @returns {Promise} Approval promise
   */
  async approveJoinRequest(requestId) {
    try {
      console.log('✅ Approving join request:', requestId);
      
      // Try Firebase transaction
      try {
        await runTransaction(db, async (transaction) => {
          // Get the join request
          const requestRef = doc(db, 'clubJoinRequests', requestId);
          const requestDoc = await transaction.get(requestRef);
          
          if (!requestDoc.exists()) {
            throw new Error('Join request not found');
          }
          
          const requestData = requestDoc.data();
          
          // Update request status
          transaction.update(requestRef, {
            status: 'approved',
            approvedAt: serverTimestamp()
          });
          
          // Add user to club members
          const membershipId = `${requestData.clubId}_${requestData.userId}`;
          const memberRef = doc(db, 'clubMembers', membershipId);
          
          const memberDoc = {
            clubId: requestData.clubId,
            userId: requestData.userId,
            role: 'member',
            status: 'active',
            joinedAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
            memberInfo: {
              joinedViaRequest: true,
              requestId: requestId
            }
          };
          
          transaction.set(memberRef, memberDoc);
          
          // Update club statistics
          const clubRef = doc(db, 'tennis_clubs', requestData.clubId);
          transaction.update(clubRef, {
            'statistics.totalMembers': increment(1),
            'statistics.activeMembers': increment(1),
            updatedAt: serverTimestamp()
          });
        });
        
        console.log('✅ Join request approved successfully in Firebase');
        return true;
        
      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable, using mock approval:', firebaseError.message);
        
        // Simulate async operation
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        console.log('✅ Mock join request approval successful');
        return true;
      }
    } catch (error) {
      console.error('❌ Failed to approve join request:', error);
      throw new Error('가입 신청 승인 중 오류가 발생했습니다: ' + error.message);
    }
  }

  /**
   * Decline join request
   * @param {string} requestId - Join request ID
   * @returns {Promise} Decline promise
   */
  async declineJoinRequest(requestId) {
    try {
      console.log('❌ Declining join request:', requestId);
      
      // Try Firebase update
      try {
        const requestRef = doc(db, 'clubJoinRequests', requestId);
        await updateDoc(requestRef, {
          status: 'declined',
          declinedAt: serverTimestamp()
        });
        
        console.log('✅ Join request declined successfully in Firebase');
        return true;
        
      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable, using mock decline:', firebaseError.message);
        
        // Simulate async operation
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        console.log('✅ Mock join request decline successful');
        return true;
      }
    } catch (error) {
      console.error('❌ Failed to decline join request:', error);
      throw new Error('가입 신청 거절 중 오류가 발생했습니다: ' + error.message);
    }
  }

  /**
   * Get detailed club information
   * @param {string} clubId - Club ID
   * @returns {Promise<Object>} Club details
   */
  async getClubDetails(clubId) {
    try {
      console.log('🔍 Getting club details for:', clubId);
      
      // Try Firebase first
      try {
        const clubRef = doc(db, 'tennis_clubs', clubId);
        const clubDoc = await getDoc(clubRef);
        
        if (clubDoc.exists()) {
          const clubData = clubDoc.data();
          console.log('✅ Club details retrieved from Firebase:', clubData);
          
          // Format the data for the UI
          return {
            id: clubDoc.id,
            name: clubData.profile?.name || clubData.name || '',
            description: clubData.profile?.description || clubData.description || '',
            logoUri: clubData.profile?.logo || clubData.logoUrl || '',
            logoUrl: clubData.profile?.logo || clubData.logoUrl || '',
            region: clubData.profile?.location || clubData.location || '',
            isPublic: clubData.settings?.isPublic ?? clubData.isPublic ?? true,
            maxMembers: clubData.settings?.maxMembers || clubData.maxMembers || 100,
            membershipFee: clubData.settings?.membershipFee || 0,
            joinFee: clubData.settings?.joinFee || 0,
            facilities: clubData.profile?.facilities || [],
            rules: clubData.profile?.rules || [],
            courtAddress: clubData.profile?.courtAddress || null,
            meetings: clubData.settings?.meetings || [],
            tags: clubData.profile?.tags || clubData.tags || [],
            contactInfo: clubData.profile?.contactInfo || clubData.contactInfo || null,
            establishedDate: clubData.profile?.establishedDate || clubData.establishedDate,
            createdBy: clubData.createdBy,
            status: clubData.status || 'active'
          };
        } else {
          throw new Error('Club not found');
        }
      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable, using mock data:', firebaseError.message);
        
        // Return mock data for testing
        return {
          id: clubId,
          name: 'Mock Tennis Club',
          description: 'This is a mock tennis club for testing purposes.',
          logoUri: '',
          region: 'Seoul',
          isPublic: true,
          maxMembers: 100,
          membershipFee: 0,
          tags: ['tennis', 'sports'],
          contactInfo: null,
          establishedDate: new Date(),
          createdBy: 'mock-user',
          status: 'active'
        };
      }
    } catch (error) {
      console.error('❌ Failed to get club details:', error);
      throw error;
    }
  }

  /**
   * Update club information
   * @param {string} clubId - Club ID
   * @param {Object} updateData - Data to update
   * @returns {Promise} Update promise
   */
  async updateClub(clubId, updateData) {
    try {
      console.log('📝 Updating club:', clubId, updateData);
      
      // Try to get current user
      let currentUser;
      try {
        currentUser = authService.getCurrentUser();
      } catch (authError) {
        console.warn('⚠️ Auth service unavailable, using mock update');
        currentUser = { uid: 'mock-user-id' };
      }
      
      if (!currentUser) {
        throw new Error('User must be authenticated');
      }

      // Try Firebase update
      try {
        const clubRef = doc(db, 'tennis_clubs', clubId);
        
        // Prepare update document with proper structure
        const updateFields = {
          'profile.name': updateData.name,
          'profile.description': updateData.description,
          'profile.location': updateData.region,
          'settings.isPublic': updateData.isPublic,
          updatedAt: serverTimestamp()
        };
        
        // Only update logo if provided
        if (updateData.logoUri !== undefined) {
          updateFields['profile.logo'] = updateData.logoUri;
        }
        
        // Only update other fields if provided
        if (updateData.maxMembers !== undefined) {
          updateFields['settings.maxMembers'] = updateData.maxMembers;
        }
        
        if (updateData.monthlyFee !== undefined) {
          updateFields['settings.membershipFee'] = updateData.monthlyFee;
        }
        
        if (updateData.joinFee !== undefined) {
          updateFields['settings.joinFee'] = updateData.joinFee;
        }
        
        if (updateData.facilities !== undefined) {
          updateFields['profile.facilities'] = updateData.facilities;
        }
        
        if (updateData.rules !== undefined) {
          updateFields['profile.rules'] = updateData.rules;
        }
        
        if (updateData.tags !== undefined) {
          updateFields['profile.tags'] = updateData.tags;
        }
        
        await updateDoc(clubRef, updateFields);
        
        console.log('✅ Club updated successfully in Firebase');
        return true;
        
      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable, using mock update:', firebaseError.message);
        
        // Simulate async operation
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        console.log('✅ Mock club update successful');
        return true;
      }
    } catch (error) {
      console.error('❌ Failed to update club:', error);
      throw new Error('클럽 정보 수정 중 오류가 발생했습니다: ' + error.message);
    }
  }

  // ============ MEMBER MANAGEMENT ============

  /**
   * Get club members
   * @param {string} clubId - Club ID
   * @returns {Promise<Array>} Array of club members
   */
  async getClubMembers(clubId) {
    try {
      const membersRef = collection(db, 'clubMembers');
      const q = query(
        membersRef,
        where('clubId', '==', clubId),
        where('status', '==', 'active'),
        orderBy('role', 'asc'),
        orderBy('joinedAt', 'desc')
      );

      const snapshot = await getDocs(q);
      const members = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));

      console.log(`✅ Found ${members.length} club members`);
      return members;
    } catch (error) {
      console.error('❌ Failed to get club members:', error);
      throw error;
    }
  }

  /**
   * Invite member to club
   * @param {string} clubId - Club ID
   * @param {Object} inviteData - Invitation data
   * @returns {Promise<string>} Invitation ID
   */
  async inviteMember(clubId, inviteData) {
    try {
      const currentUser = authService.getCurrentUser();
      if (!currentUser) throw new Error('User must be authenticated');

      // Check permissions
      const canInvite = await this.checkClubPermission(clubId, 'manager');
      if (!canInvite) {
        throw new Error('Insufficient permissions to invite members');
      }

      // Get club info
      const clubData = await this.getClub(clubId);
      
      const invitationsRef = collection(db, 'clubInvitations');
      const invitationDoc = {
        clubId,
        clubInfo: {
          name: clubData.name,
          logoUrl: clubData.logoUrl
        },
        invitedEmail: inviteData.email,
        invitedBy: currentUser.uid,
        inviterInfo: {
          displayName: currentUser.displayName || 'Club Member',
          role: 'admin' // Get actual role from membership
        },
        status: 'pending',
        message: inviteData.message || '',
        createdAt: serverTimestamp(),
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days
      };

      const docRef = await addDoc(invitationsRef, invitationDoc);
      
      console.log('✅ Member invitation sent:', docRef.id);
      return docRef.id;
    } catch (error) {
      console.error('❌ Failed to invite member:', error);
      throw error;
    }
  }

  /**
   * Get club members with enhanced details
   * @param {string} clubId - Club ID
   * @param {string} status - Member status filter ('active', 'pending', 'inactive')
   * @returns {Promise<Array>} Array of club members with user details
   */
  async getClubMembers(clubId, status = 'active') {
    try {
      console.log('🔍 Getting club members for:', clubId);
      
      // Try Firebase first
      try {
        const membersRef = collection(db, 'clubMembers');
        let q = query(
          membersRef, 
          where('clubId', '==', clubId),
          where('status', '==', status)
        );
        
        const querySnapshot = await getDocs(q);
        const members = [];
        
        console.log(`🔍 Found ${querySnapshot.size} members`);
        
        for (const docSnap of querySnapshot.docs) {
          const memberData = docSnap.data();
          
          // Get user information from users collection
          let userInfo = null;
          try {
            const userDoc = await getDoc(doc(db, 'users', memberData.userId));
            if (userDoc.exists()) {
              userInfo = userDoc.data();
            }
          } catch (userError) {
            console.error('Error fetching user data:', userError);
          }
          
          members.push({
            id: docSnap.id,
            userId: memberData.userId,
            userName: userInfo?.profile?.nickname || 
                     userInfo?.displayName ||
                     memberData.memberInfo?.displayName || 
                     memberData.memberInfo?.nickname || 
                     'Unknown User',
            profileImage: userInfo?.profile?.photoURL || 
                         userInfo?.photoURL ||
                         memberData.memberInfo?.photoURL,
            skillLevel: userInfo?.profile?.skillLevel || memberData.memberInfo?.skillLevel,
            role: memberData.role || 'member',
            status: memberData.status || 'active',
            joinedAt: memberData.joinedAt?.toDate() || memberData.createdAt?.toDate() || new Date(),
            lastActive: memberData.clubActivity?.lastActiveAt?.toDate(),
            eventsAttended: memberData.clubActivity?.eventsAttended || 0,
          });
        }
        
        // Sort by role priority then by join date
        members.sort((a, b) => {
          const roleOrder = { owner: 1, admin: 2, member: 3 };
          const aRole = roleOrder[a.role] || 3;
          const bRole = roleOrder[b.role] || 3;
          
          if (aRole !== bRole) {
            return aRole - bRole;
          }
          
          return b.joinedAt.getTime() - a.joinedAt.getTime();
        });
        
        console.log(`✅ Loaded ${members.length} club members from Firebase`);
        return members;
        
      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable, using mock data:', firebaseError.message);
        
        // Return mock data for testing
        return [
          {
            id: 'mock-member-1',
            userId: 'user1',
            userName: '김관리자',
            profileImage: null,
            skillLevel: 4.0,
            role: 'admin',
            status: 'active',
            joinedAt: new Date('2024-01-15'),
            lastActive: new Date(),
            eventsAttended: 12,
          },
          {
            id: 'mock-member-2',
            userId: 'user2',
            userName: '이멤버',
            profileImage: null,
            skillLevel: 3.5,
            role: 'member',
            status: 'active',
            joinedAt: new Date('2024-02-01'),
            lastActive: new Date(),
            eventsAttended: 8,
          },
          {
            id: 'mock-member-3',
            userId: 'user3',
            userName: '박멤버',
            profileImage: null,
            skillLevel: 3.0,
            role: 'member',
            status: 'active',
            joinedAt: new Date('2024-02-15'),
            lastActive: new Date(),
            eventsAttended: 5,
          },
        ];
      }
    } catch (error) {
      console.error('❌ Failed to get club members:', error);
      throw error;
    }
  }

  /**
   * Update member role
   * @param {string} clubId - Club ID
   * @param {string} userId - User ID
   * @param {string} newRole - New role (admin, member)
   * @returns {Promise} Update promise
   */
  async updateMemberRole(clubId, userId, newRole) {
    try {
      console.log('📝 Updating member role:', { clubId, userId, newRole });
      
      // Try to get current user for permission check
      let currentUser;
      try {
        currentUser = authService.getCurrentUser();
      } catch (authError) {
        console.warn('⚠️ Auth service unavailable, proceeding with mock update');
        currentUser = { uid: 'mock-admin-user' };
      }
      
      if (!currentUser) {
        throw new Error('User must be authenticated');
      }

      // Try Firebase update
      try {
        const membershipId = `${clubId}_${userId}`;
        const memberRef = doc(db, 'clubMembers', membershipId);
        
        await updateDoc(memberRef, {
          role: newRole,
          updatedAt: serverTimestamp()
        });
        
        console.log('✅ Member role updated successfully in Firebase');
        return true;
        
      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable, using mock update:', firebaseError.message);
        
        // Simulate async operation
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        console.log('✅ Mock member role update successful');
        return true;
      }
    } catch (error) {
      console.error('❌ Failed to update member role:', error);
      throw new Error('멤버 역할 변경 중 오류가 발생했습니다: ' + error.message);
    }
  }

  /**
   * Remove member from club
   * @param {string} clubId - Club ID
   * @param {string} userId - User ID to remove
   * @returns {Promise} Remove promise
   */
  async removeMember(clubId, userId) {
    try {
      console.log('🗑️ Removing member:', { clubId, userId });
      
      // Try to get current user for permission check
      let currentUser;
      try {
        currentUser = authService.getCurrentUser();
      } catch (authError) {
        console.warn('⚠️ Auth service unavailable, proceeding with mock removal');
        currentUser = { uid: 'mock-admin-user' };
      }
      
      if (!currentUser) {
        throw new Error('User must be authenticated');
      }

      // Try Firebase removal
      try {
        await runTransaction(db, async (transaction) => {
          const membershipId = `${clubId}_${userId}`;
          const memberRef = doc(db, 'clubMembers', membershipId);
          
          // Remove membership document
          transaction.delete(memberRef);
          
          // Update club stats
          const clubRef = doc(db, 'tennis_clubs', clubId);
          transaction.update(clubRef, {
            'statistics.totalMembers': increment(-1),
            'statistics.activeMembers': increment(-1),
            updatedAt: serverTimestamp()
          });
        });
        
        console.log('✅ Member removed successfully from Firebase');
        return true;
        
      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable, using mock removal:', firebaseError.message);
        
        // Simulate async operation
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        console.log('✅ Mock member removal successful');
        return true;
      }
    } catch (error) {
      console.error('❌ Failed to remove member:', error);
      throw new Error('멤버 제거 중 오류가 발생했습니다: ' + error.message);
    }
  }

  /**
   * Get all clubs that a user is a member of
   * @param {string} userId - User ID
   * @returns {Promise<Array>} Array of user's club memberships
   */
  async getUserClubMemberships(userId) {
    try {
      console.log('🔍 Getting club memberships for user:', userId);
      
      // 단순한 쿼리로 시작 (orderBy 제거하여 인덱스 문제 방지)
      const membershipsQuery = query(
        collection(db, 'clubMembers'),
        where('userId', '==', userId)
      );

      console.log('🔍 Executing clubMembers query...');
      const querySnapshot = await getDocs(membershipsQuery);
      console.log(`🔍 Found ${querySnapshot.size} membership records`);
      
      const userClubs = [];

      // 각 멤버십에 대해 클럽 정보 가져오기
      for (const memberDoc of querySnapshot.docs) {
        const memberData = memberDoc.data();
        console.log('🔍 Processing membership:', memberDoc.id, memberData);
        
        // active 또는 pending 상태만 필터링
        if (!['active', 'pending'].includes(memberData.status)) {
          console.log('⏭️ Skipping non-active membership:', memberData.status);
          continue;
        }
        
        // 클럽 정보 가져오기
        const clubRef = doc(db, 'tennis_clubs', memberData.clubId);
        console.log('🔍 Getting club info for:', memberData.clubId);
        
        try {
          const clubDoc = await getDoc(clubRef);
          
          if (clubDoc.exists()) {
            const clubData = clubDoc.data();
            console.log('🔍 Found club data:', clubData);
            
            // 클럽의 현재 멤버 수 계산 (간단한 쿼리로)
            const memberCountQuery = query(
              collection(db, 'clubMembers'),
              where('clubId', '==', memberData.clubId),
              where('status', '==', 'active')
            );
            const memberCountSnapshot = await getDocs(memberCountQuery);
            const memberCount = memberCountSnapshot.size;

            userClubs.push({
              id: memberDoc.id, // 멤버십 ID
              clubId: memberData.clubId,
              clubName: clubData.profile?.name || clubData.name || 'Unknown Club',
              clubDescription: clubData.profile?.description || clubData.description,
              clubLocation: clubData.profile?.location || clubData.location || 'Unknown Location',
              clubLogo: clubData.profile?.logo || clubData.logoUrl || null,
              role: memberData.role || 'member',
              status: memberData.status || 'active',
              joinedAt: memberData.joinedAt?.toDate() || memberData.createdAt?.toDate() || new Date(),
              memberCount: memberCount,
              // 클럽 추가 정보
              clubTags: clubData.profile?.tags || clubData.tags || [],
              clubContactInfo: clubData.profile?.contactInfo || clubData.contactInfo,
              clubIsPublic: clubData.settings?.isPublic ?? clubData.isPublic ?? true,
              clubMaxMembers: clubData.settings?.maxMembers || clubData.maxMembers,
              clubEstablishedDate: clubData.profile?.establishedDate?.toDate() || clubData.establishedDate?.toDate(),
            });
          } else {
            console.log('⚠️ Club not found:', memberData.clubId);
          }
        } catch (clubError) {
          console.error('❌ Error getting club data for', memberData.clubId, clubError);
          // 클럽 정보를 가져올 수 없어도 계속 진행
          userClubs.push({
            id: memberDoc.id,
            clubId: memberData.clubId,
            clubName: 'Unknown Club',
            clubDescription: 'Club information unavailable',
            clubLocation: 'Unknown Location',
            role: memberData.role || 'member',
            status: memberData.status || 'active',
            joinedAt: memberData.joinedAt?.toDate() || new Date(),
            memberCount: 0,
            clubTags: [],
            clubContactInfo: null,
            clubIsPublic: true,
            clubMaxMembers: null,
            clubEstablishedDate: null,
          });
        }
      }

      // 가입일 기준으로 정렬 (클라이언트에서)
      userClubs.sort((a, b) => b.joinedAt.getTime() - a.joinedAt.getTime());

      console.log(`✅ Retrieved ${userClubs.length} club memberships for user ${userId}`);
      return userClubs;

    } catch (error) {
      console.error('❌ Error getting user club memberships:', error);
      console.error('Error details:', error.message, error.stack);
      // 에러 발생시 빈 배열 반환하여 UI에서 empty state 표시
      return [];
    }
  }

  /**
   * Join club (accept invitation or direct join)
   * @param {string} clubId - Club ID
   * @param {string} invitationId - Optional invitation ID
   * @returns {Promise} Join promise
   */
  async joinClub(clubId, invitationId = null) {
    try {
      const currentUser = authService.getCurrentUser();
      if (!currentUser) throw new Error('User must be authenticated');

      // Check if already a member
      const membershipId = `${clubId}_${currentUser.uid}`;
      const memberRef = doc(db, 'clubMembers', membershipId);
      const memberSnap = await getDoc(memberRef);

      if (memberSnap.exists() && memberSnap.data().status === 'active') {
        throw new Error('Already a member of this club');
      }

      // Get club data
      const clubData = await this.getClub(clubId);

      // Join club in a transaction
      await runTransaction(db, async (transaction) => {
        // Create/update membership
        const memberDoc = {
          clubId,
          userId: currentUser.uid,
          role: 'member',
          status: clubData.settings.joinRequiresApproval ? 'pending' : 'active',
          memberInfo: {
            displayName: currentUser.displayName || '',
            nickname: currentUser.displayName || '',
            photoURL: currentUser.photoURL || '',
            skillLevel: 'intermediate', // Get from user profile
            preferredLanguage: 'en'
          },
          clubActivity: {
            eventsAttended: 0,
            lastActiveAt: serverTimestamp(),
            joinDate: serverTimestamp(),
            memberSince: 'Just joined'
          },
          permissions: {
            canCreateEvents: false,
            canModerateChat: false,
            canInviteMembers: false,
            canManageMembers: false
          },
          notifications: {
            clubEvents: true,
            clubChat: true,
            memberUpdates: true,
            announcements: true
          },
          joinedAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        };

        transaction.set(memberRef, memberDoc);

        // Update club stats if approved immediately
        if (!clubData.settings.joinRequiresApproval) {
          const clubRef = doc(db, 'clubs', clubId);
          transaction.update(clubRef, {
            'stats.totalMembers': increment(1),
            'stats.activeMembers': increment(1),
            updatedAt: serverTimestamp()
          });
        }

        // Update invitation status if provided
        if (invitationId) {
          const invitationRef = doc(db, 'clubInvitations', invitationId);
          transaction.update(invitationRef, {
            status: 'accepted',
            respondedAt: serverTimestamp()
          });
        }

        // Update user's club memberships
        const userRef = doc(db, 'users', currentUser.uid);
        transaction.update(userRef, {
          'clubs.memberships': arrayUnion(clubId),
          updatedAt: serverTimestamp()
        });
      });

      console.log('✅ Successfully joined club');
    } catch (error) {
      console.error('❌ Failed to join club:', error);
      throw error;
    }
  }

  /**
   * Leave club
   * @param {string} clubId - Club ID
   * @returns {Promise} Leave promise
   */
  async leaveClub(clubId) {
    try {
      const currentUser = authService.getCurrentUser();
      if (!currentUser) throw new Error('User must be authenticated');

      const membershipId = `${clubId}_${currentUser.uid}`;
      
      await runTransaction(db, async (transaction) => {
        // Update membership status
        const memberRef = doc(db, 'clubMembers', membershipId);
        transaction.update(memberRef, {
          status: 'left',
          updatedAt: serverTimestamp()
        });

        // Update club stats
        const clubRef = doc(db, 'clubs', clubId);
        transaction.update(clubRef, {
          'stats.totalMembers': increment(-1),
          'stats.activeMembers': increment(-1),
          updatedAt: serverTimestamp()
        });

        // Update user's club memberships
        const userRef = doc(db, 'users', currentUser.uid);
        transaction.update(userRef, {
          'clubs.memberships': arrayRemove(clubId),
          'clubs.adminOf': arrayRemove(clubId), // Remove from admin if applicable
          updatedAt: serverTimestamp()
        });
      });

      console.log('✅ Successfully left club');
    } catch (error) {
      console.error('❌ Failed to leave club:', error);
      throw error;
    }
  }

  // ============ EVENT MANAGEMENT ============

  /**
   * Create club event
   * @param {string} clubId - Club ID
   * @param {Object} eventData - Event information
   * @returns {Promise<string>} Created event ID
   */
  async createClubEvent(clubId, eventData) {
    try {
      const currentUser = authService.getCurrentUser();
      if (!currentUser) throw new Error('User must be authenticated');

      // Check permissions
      const canCreate = await this.checkClubPermission(clubId, 'manager');
      if (!canCreate) {
        throw new Error('Insufficient permissions to create events');
      }

      const eventsRef = collection(db, 'clubEvents');
      const eventDoc = {
        ...eventData,
        clubId,
        participants: {
          maxParticipants: eventData.maxParticipants || null,
          currentCount: 0,
          registeredIds: [],
          waitlistIds: [],
          attendedIds: []
        },
        status: 'published',
        createdBy: currentUser.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      const docRef = await addDoc(eventsRef, eventDoc);

      // Update club stats
      const clubRef = doc(db, 'clubs', clubId);
      await updateDoc(clubRef, {
        'stats.totalEvents': increment(1),
        'stats.monthlyEvents': increment(1),
        updatedAt: serverTimestamp()
      });

      console.log('✅ Club event created:', docRef.id);
      return docRef.id;
    } catch (error) {
      console.error('❌ Failed to create club event:', error);
      throw error;
    }
  }

  /**
   * Get club events
   * @param {string} clubId - Club ID
   * @param {Object} filters - Event filters
   * @returns {Promise<Array>} Array of club events
   */
  async getClubEvents(clubId, filters = {}) {
    try {
      const eventsRef = collection(db, 'clubEvents');
      let q = query(
        eventsRef,
        where('clubId', '==', clubId),
        where('status', 'in', ['published', 'ongoing']),
        orderBy('schedule.startTime', 'asc'),
        limit(50)
      );

      // Apply date filter for upcoming events
      if (filters.upcoming) {
        q = query(q, where('schedule.startTime', '>', new Date()));
      }

      const snapshot = await getDocs(q);
      const events = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));

      console.log(`✅ Found ${events.length} club events`);
      return events;
    } catch (error) {
      console.error('❌ Failed to get club events:', error);
      throw error;
    }
  }

  /**
   * Join club event
   * @param {string} eventId - Event ID
   * @returns {Promise} Join promise
   */
  async joinEvent(eventId) {
    try {
      const currentUser = authService.getCurrentUser();
      if (!currentUser) throw new Error('User must be authenticated');

      await runTransaction(db, async (transaction) => {
        const eventRef = doc(db, 'clubEvents', eventId);
        const eventDoc = await transaction.get(eventRef);

        if (!eventDoc.exists()) {
          throw new Error('Event not found');
        }

        const eventData = eventDoc.data();
        const registeredIds = eventData.participants.registeredIds || [];
        
        if (registeredIds.includes(currentUser.uid)) {
          throw new Error('Already registered for this event');
        }

        // Check if event is full
        const maxParticipants = eventData.participants.maxParticipants;
        if (maxParticipants && registeredIds.length >= maxParticipants) {
          throw new Error('Event is full');
        }

        // Add user to participants
        transaction.update(eventRef, {
          'participants.registeredIds': arrayUnion(currentUser.uid),
          'participants.currentCount': increment(1),
          updatedAt: serverTimestamp()
        });
      });

      console.log('✅ Successfully joined event');
    } catch (error) {
      console.error('❌ Failed to join event:', error);
      throw error;
    }
  }

  // ============ CHAT MANAGEMENT ============

  /**
   * Send message to club chat
   * @param {string} clubId - Club ID
   * @param {Object} messageData - Message data
   * @returns {Promise<string>} Message ID
   */
  async sendClubMessage(clubId, messageData) {
    try {
      const currentUser = authService.getCurrentUser();
      if (!currentUser) throw new Error('User must be authenticated');

      // Check if user is club member
      const isMember = await this.checkClubMembership(clubId);
      if (!isMember) {
        throw new Error('Must be a club member to send messages');
      }

      const chatRef = collection(db, 'clubChat');
      const messageDoc = {
        clubId,
        senderId: currentUser.uid,
        senderInfo: {
          displayName: currentUser.displayName || '',
          nickname: currentUser.displayName || '',
          photoURL: currentUser.photoURL || '',
          role: 'member' // Get actual role from membership
        },
        content: {
          text: messageData.text || '',
          imageUrls: messageData.imageUrls || [],
          attachments: messageData.attachments || []
        },
        type: messageData.type || 'message',
        relatedEventId: messageData.relatedEventId || null,
        replyTo: messageData.replyTo || null,
        isEdited: false,
        isDeleted: false,
        readBy: {
          [currentUser.uid]: serverTimestamp()
        },
        createdAt: serverTimestamp()
      };

      const docRef = await addDoc(chatRef, messageDoc);
      
      console.log('✅ Club message sent:', docRef.id);
      return docRef.id;
    } catch (error) {
      console.error('❌ Failed to send club message:', error);
      throw error;
    }
  }

  /**
   * Get club chat messages
   * @param {string} clubId - Club ID
   * @param {number} limitCount - Message limit
   * @returns {Promise<Array>} Array of messages
   */
  async getClubMessages(clubId, limitCount = 50) {
    try {
      const chatRef = collection(db, 'clubChat');
      const q = query(
        chatRef,
        where('clubId', '==', clubId),
        where('isDeleted', '==', false),
        orderBy('createdAt', 'desc'),
        limit(limitCount)
      );

      const snapshot = await getDocs(q);
      const messages = snapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() }))
        .reverse(); // Reverse to get chronological order

      console.log(`✅ Retrieved ${messages.length} club messages`);
      return messages;
    } catch (error) {
      console.error('❌ Failed to get club messages:', error);
      throw error;
    }
  }

  // ============ UTILITY FUNCTIONS ============

  /**
   * Check user's club membership
   * @param {string} clubId - Club ID
   * @returns {Promise<boolean>} Membership status
   */
  async checkClubMembership(clubId) {
    try {
      const currentUser = authService.getCurrentUser();
      if (!currentUser) return false;

      const membershipId = `${clubId}_${currentUser.uid}`;
      const memberRef = doc(db, 'clubMembers', membershipId);
      const memberSnap = await getDoc(memberRef);

      return memberSnap.exists() && memberSnap.data().status === 'active';
    } catch (error) {
      console.error('❌ Failed to check membership:', error);
      return false;
    }
  }

  /**
   * Check user's club permissions
   * @param {string} clubId - Club ID
   * @param {string} requiredRole - Required minimum role
   * @returns {Promise<boolean>} Permission status
   */
  async checkClubPermission(clubId, requiredRole = 'member') {
    try {
      const currentUser = authService.getCurrentUser();
      if (!currentUser) return false;

      const membershipId = `${clubId}_${currentUser.uid}`;
      const memberRef = doc(db, 'clubMembers', membershipId);
      const memberSnap = await getDoc(memberRef);

      if (!memberSnap.exists() || memberSnap.data().status !== 'active') {
        return false;
      }

      const userRole = memberSnap.data().role;
      const roleHierarchy = { member: 1, manager: 2, admin: 3 };
      
      return roleHierarchy[userRole] >= roleHierarchy[requiredRole];
    } catch (error) {
      console.error('❌ Failed to check permissions:', error);
      return false;
    }
  }

  /**
   * Get user's clubs
   * @returns {Promise<Array>} Array of user's clubs
   */
  async getUserClubs() {
    try {
      const currentUser = authService.getCurrentUser();
      if (!currentUser) return [];

      const membersRef = collection(db, 'clubMembers');
      const q = query(
        membersRef,
        where('userId', '==', currentUser.uid),
        where('status', '==', 'active'),
        orderBy('joinedAt', 'desc')
      );

      const snapshot = await getDocs(q);
      const memberships = snapshot.docs.map(doc => doc.data());

      // Get club details for each membership
      const clubPromises = memberships.map(membership => 
        this.getClub(membership.clubId)
      );
      const clubs = await Promise.all(clubPromises);

      console.log(`✅ Found ${clubs.length} user clubs`);
      return clubs.map((club, index) => ({
        ...club,
        userRole: memberships[index].role,
        joinedAt: memberships[index].joinedAt
      }));
    } catch (error) {
      console.error('❌ Failed to get user clubs:', error);
      throw error;
    }
  }

  // ============ REAL-TIME LISTENERS ============

  /**
   * Subscribe to club updates
   * @param {string} clubId - Club ID
   * @param {Function} callback - Update callback
   * @returns {Function} Unsubscribe function
   */
  subscribeToClub(clubId, callback) {
    const clubRef = doc(db, 'clubs', clubId);
    return onSnapshot(clubRef, (doc) => {
      if (doc.exists()) {
        callback({ id: doc.id, ...doc.data() });
      }
    });
  }

  /**
   * Subscribe to club chat messages
   * @param {string} clubId - Club ID
   * @param {Function} callback - Message callback
   * @returns {Function} Unsubscribe function
   */
  subscribeToClubChat(clubId, callback) {
    const chatRef = collection(db, 'clubChat');
    const q = query(
      chatRef,
      where('clubId', '==', clubId),
      where('isDeleted', '==', false),
      orderBy('createdAt', 'desc'),
      limit(50)
    );

    return onSnapshot(q, (snapshot) => {
      const messages = snapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() }))
        .reverse();
      callback(messages);
    });
  }

  // ============ SCHEDULE MANAGEMENT ============

  /**
   * Create a new club schedule template
   * @param {string} clubId - Club ID
   * @param {Object} scheduleData - Schedule data
   * @returns {Promise<string>} Created schedule ID
   */
  async createClubSchedule(clubId, scheduleData) {
    try {
      console.log('📅 Creating club schedule:', clubId, scheduleData);
      
      // Try to get current user
      let currentUser;
      try {
        currentUser = authService.getCurrentUser();
      } catch (authError) {
        console.warn('⚠️ Auth service unavailable, using mock user');
        currentUser = { uid: 'mock-user-id' };
      }

      if (!currentUser) {
        throw new Error('로그인이 필요합니다.');
      }

      const scheduleDoc = {
        clubId: clubId,
        title: scheduleData.title,
        location: scheduleData.location,
        dayOfWeek: scheduleData.dayOfWeek, // 0-6 (Sunday-Saturday)
        startTime: scheduleData.startTime, // "HH:MM" format
        endTime: scheduleData.endTime, // "HH:MM" format
        isActive: scheduleData.isActive || true,
        createdAt: serverTimestamp(),
        createdBy: currentUser.uid,
        updatedAt: serverTimestamp()
      };

      // Try Firebase first
      try {
        const schedulesRef = collection(db, 'clubSchedules');
        const docRef = await addDoc(schedulesRef, scheduleDoc);
        
        console.log('✅ Club schedule created successfully in Firebase:', docRef.id);
        return docRef.id;
        
      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable, using mock schedule creation:', firebaseError.message);
        
        // Simulate async operation
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        const mockScheduleId = `mock-schedule-${Date.now()}`;
        console.log('✅ Mock club schedule creation successful:', mockScheduleId);
        return mockScheduleId;
      }
    } catch (error) {
      console.error('❌ Failed to create club schedule:', error);
      throw new Error('정기 모임 생성 중 오류가 발생했습니다: ' + error.message);
    }
  }

  /**
   * Get all club schedule templates
   * @param {string} clubId - Club ID
   * @returns {Promise<Array>} Array of club schedules
   */
  async getClubSchedules(clubId) {
    try {
      console.log('📅 Getting club schedules for:', clubId);
      
      // Try Firebase first
      try {
        const schedulesRef = collection(db, 'clubSchedules');
        const q = query(
          schedulesRef,
          where('clubId', '==', clubId),
          where('isActive', '==', true),
          orderBy('dayOfWeek', 'asc'),
          orderBy('startTime', 'asc')
        );

        const snapshot = await getDocs(q);
        const schedules = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
          createdAt: doc.data().createdAt?.toDate() || new Date(),
          updatedAt: doc.data().updatedAt?.toDate() || new Date()
        }));

        console.log(`✅ Found ${schedules.length} club schedules`);
        return schedules;
        
      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable, returning mock schedules:', firebaseError.message);
        
        // Return mock data for development
        const mockSchedules = [
          {
            id: 'mock-schedule-1',
            clubId: clubId,
            title: '주말 단식 연습',
            location: '중앙공원 테니스장',
            dayOfWeek: 6, // 토요일
            startTime: '09:00',
            endTime: '11:00',
            isActive: true,
            createdAt: new Date('2024-01-01'),
            createdBy: 'mock-user-id',
            updatedAt: new Date('2024-01-01')
          },
          {
            id: 'mock-schedule-2',
            clubId: clubId,
            title: '평일 저녁 복식',
            location: '시립 테니스장',
            dayOfWeek: 3, // 수요일
            startTime: '19:00',
            endTime: '21:00',
            isActive: true,
            createdAt: new Date('2024-01-01'),
            createdBy: 'mock-user-id',
            updatedAt: new Date('2024-01-01')
          }
        ];
        
        console.log(`✅ Returning ${mockSchedules.length} mock schedules`);
        return mockSchedules;
      }
    } catch (error) {
      console.error('❌ Failed to get club schedules:', error);
      throw new Error('정기 모임 목록을 불러오는 중 오류가 발생했습니다: ' + error.message);
    }
  }

  /**
   * Delete a club schedule template
   * @param {string} scheduleId - Schedule ID
   * @returns {Promise} Delete promise
   */
  async deleteClubSchedule(scheduleId) {
    try {
      console.log('🗑️ Deleting club schedule:', scheduleId);
      
      // Try to get current user
      let currentUser;
      try {
        currentUser = authService.getCurrentUser();
      } catch (authError) {
        console.warn('⚠️ Auth service unavailable, using mock user');
        currentUser = { uid: 'mock-user-id' };
      }

      if (!currentUser) {
        throw new Error('로그인이 필요합니다.');
      }

      // Try Firebase first
      try {
        const scheduleRef = doc(db, 'clubSchedules', scheduleId);
        
        // Soft delete by setting isActive to false
        await updateDoc(scheduleRef, {
          isActive: false,
          deletedAt: serverTimestamp(),
          deletedBy: currentUser.uid
        });
        
        console.log('✅ Club schedule deleted successfully in Firebase');
        return true;
        
      } catch (firebaseError) {
        console.warn('⚠️ Firebase unavailable, using mock deletion:', firebaseError.message);
        
        // Simulate async operation
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        console.log('✅ Mock club schedule deletion successful');
        return true;
      }
    } catch (error) {
      console.error('❌ Failed to delete club schedule:', error);
      throw new Error('정기 모임 삭제 중 오류가 발생했습니다: ' + error.message);
    }
  }

  // ============ AUTOMATIC EVENT CREATION (Cloud Function Logic) ============
  
  /*
   * 📋 CLOUD FUNCTION DESIGN FOR AUTOMATIC EVENT CREATION
   * 
   * 이 섹션은 Firebase Cloud Functions에서 구현될 자동 이벤트 생성 로직의 설계를 설명합니다.
   * 실제 구현이 아닌 개념적 설계이며, 주석으로 작성되었습니다.
   * 
   * === 예약된 Cloud Function 설정 ===
   * 
   * 1. 스케줄 설정: 매주 월요일 새벽 2시에 실행
   *    - exports.createWeeklyEvents = functions.pubsub.schedule('0 2 * * 1')
   *    - 시간대: Asia/Seoul
   * 
   * 2. 주요 실행 로직:
   * 
   * async function createWeeklyEvents() {
   *   try {
   *     console.log('🔄 Starting weekly event creation...');
   *     
   *     // Step 1: 모든 활성 clubSchedules 조회
   *     const schedulesSnapshot = await admin.firestore()
   *       .collection('clubSchedules')
   *       .where('isActive', '==', true)
   *       .get();
   *     
   *     const schedules = schedulesSnapshot.docs.map(doc => ({
   *       id: doc.id,
   *       ...doc.data()
   *     }));
   *     
   *     console.log(`📅 Found ${schedules.length} active schedules`);
   *     
   *     // Step 2: 각 스케줄에 대해 이번 주 이벤트 생성
   *     for (const schedule of schedules) {
   *       await createEventForSchedule(schedule);
   *     }
   *     
   *     console.log('✅ Weekly event creation completed');
   *     
   *   } catch (error) {
   *     console.error('❌ Weekly event creation failed:', error);
   *     throw error;
   *   }
   * }
   * 
   * async function createEventForSchedule(schedule) {
   *   // Step 2.1: 이번 주 해당 요일 날짜 계산
   *   const today = new Date();
   *   const currentWeekStart = getStartOfWeek(today); // 이번 주 일요일
   *   const eventDate = new Date(currentWeekStart);
   *   eventDate.setDate(currentWeekStart.getDate() + schedule.dayOfWeek);
   *   
   *   // Step 2.2: 이미 해당 날짜에 이벤트가 있는지 중복 확인
   *   const existingEventsSnapshot = await admin.firestore()
   *     .collection('events')
   *     .where('clubId', '==', schedule.clubId)
   *     .where('type', '==', 'clubMeetup')
   *     .where('scheduleId', '==', schedule.id)
   *     .where('eventDate', '==', admin.firestore.Timestamp.fromDate(eventDate))
   *     .get();
   *   
   *   if (!existingEventsSnapshot.empty) {
   *     console.log(`⏭️ Event already exists for ${schedule.title} on ${eventDate.toDateString()}`);
   *     return;
   *   }
   *   
   *   // Step 2.3: 시작/종료 시간 설정
   *   const [startHours, startMinutes] = schedule.startTime.split(':').map(Number);
   *   const [endHours, endMinutes] = schedule.endTime.split(':').map(Number);
   *   
   *   const startDateTime = new Date(eventDate);
   *   startDateTime.setHours(startHours, startMinutes, 0, 0);
   *   
   *   const endDateTime = new Date(eventDate);
   *   endDateTime.setHours(endHours, endMinutes, 0, 0);
   *   
   *   // Step 2.4: 클럽 멤버 조회 (자동 참석자 등록용)
   *   const membersSnapshot = await admin.firestore()
   *     .collection('clubMembers')
   *     .where('clubId', '==', schedule.clubId)
   *     .where('status', '==', 'active')
   *     .get();
   *   
   *   const memberIds = membersSnapshot.docs.map(doc => doc.data().userId);
   *   
   *   // Step 2.5: 이벤트 문서 생성
   *   const eventData = {
   *     title: schedule.title,
   *     description: `정기 모임: ${schedule.title}`,
   *     clubId: schedule.clubId,
   *     scheduleId: schedule.id, // 어떤 스케줄로부터 생성되었는지 추적
   *     type: 'clubMeetup',
   *     location: schedule.location,
   *     eventDate: admin.firestore.Timestamp.fromDate(eventDate),
   *     startTime: admin.firestore.Timestamp.fromDate(startDateTime),
   *     endTime: admin.firestore.Timestamp.fromDate(endDateTime),
   *     maxParticipants: null, // 클럽 정기 모임은 제한 없음
   *     participants: memberIds, // 클럽 회원은 자동 승인됨 (청사진 참조)
   *     waitingList: [],
   *     status: 'active',
   *     isAutoGenerated: true, // 자동 생성 이벤트임을 표시
   *     createdAt: admin.firestore.FieldValue.serverTimestamp(),
   *     createdBy: 'system', // 시스템에 의해 자동 생성
   *     updatedAt: admin.firestore.FieldValue.serverTimestamp()
   *   };
   *   
   *   // Step 2.6: 이벤트 저장
   *   await admin.firestore().collection('events').add(eventData);
   *   
   *   console.log(`✅ Created event: ${schedule.title} for ${eventDate.toDateString()}`);
   *   
   *   // Step 2.7: 클럽 멤버들에게 푸시 알림 발송 (선택사항)
   *   // await sendNotificationToClubMembers(schedule.clubId, eventData);
   * }
   * 
   * function getStartOfWeek(date) {
   *   const result = new Date(date);
   *   const day = result.getDay();
   *   const diff = result.getDate() - day;
   *   return new Date(result.setDate(diff));
   * }
   * 
   * === 추가 고려사항 ===
   * 
   * 1. 오류 처리:
   *    - 개별 스케줄 처리 실패 시 전체 처리를 중단하지 않음
   *    - 실패한 스케줄은 로그에 기록하고 다음 스케줄 처리 계속
   * 
   * 2. 성능 최적화:
   *    - 배치 쓰기 사용으로 Firestore 쓰기 횟수 최적화
   *    - 병렬 처리로 처리 시간 단축
   * 
   * 3. 모니터링:
   *    - Cloud Logging을 통한 실행 로그 수집
   *    - 실패 시 관리자에게 알림 발송
   *    - 생성된 이벤트 수 등 메트릭 수집
   * 
   * 4. 테스트:
   *    - 단위 테스트로 개별 함수 검증
   *    - 통합 테스트로 전체 플로우 검증
   *    - 스테이징 환경에서 주간 실행 테스트
   * 
   * 이 Cloud Function은 clubSchedules 컬렉션의 데이터를 바탕으로
   * 매주 자동으로 events 컬렉션에 새 이벤트를 생성하여
   * 클럽 정기 모임의 연속성을 보장합니다.
   */
}

// Create singleton instance
const clubService = new ClubService();

export default clubService;