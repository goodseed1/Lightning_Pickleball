import React, { useState } from 'react';
import { View, StyleSheet, Pressable } from 'react-native';
import { Text, IconButton } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';

type Props = {
  title: string;
  requiredBadge?: string;
  defaultExpanded?: boolean;
  children: React.ReactNode;
  icon?: React.ReactNode;
  tone?: string;
};

export default function Section({ title, requiredBadge, defaultExpanded, children, icon, tone }: Props) {
  const [expanded, setExpanded] = useState(!!defaultExpanded);
  
  return (
    <View style={styles.container}>
      <Pressable style={styles.header} onPress={() => setExpanded((v) => !v)}>
        <MaterialCommunityIcons 
          name={expanded ? "chevron-down" : "chevron-right"} 
          size={16} 
          color="#666" 
        />
        {icon && <View style={styles.iconContainer}>{icon}</View>}
        <Text style={styles.title}>{title}</Text>
        {requiredBadge ? <Text style={styles.badge}>{requiredBadge}</Text> : null}
      </Pressable>
      {expanded ? <View style={styles.body}>{children}</View> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: '#E6E6E6',
    borderRadius: 10,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 10,
    paddingVertical: 10,
  },
  iconContainer: {
    marginLeft: 2,
  },
  title: {
    fontSize: 14,
    fontWeight: '700',
    flex: 1,
  },
  badge: {
    fontSize: 11,
    fontWeight: '600',
    color: '#B00020',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: '#F1C5C5',
    borderRadius: 999,
    overflow: 'hidden',
  },
  body: {
    paddingHorizontal: 10,
    paddingBottom: 10,
    gap: 8,
  },
});