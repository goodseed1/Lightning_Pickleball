import React, { forwardRef } from 'react';
import { Platform } from 'react-native';
import { GooglePlacesAutocomplete, GooglePlacesAutocompleteProps } from 'react-native-google-places-autocomplete';
import { safeSpread, safeArray, toArray } from '../../utils/safe';

// Re-export types for convenience
export type {
  GooglePlacesAutocompleteProps,
  GooglePlacesAutocompleteRef,
  Place,
  GooglePlaceData,
  GooglePlaceDetail,
} from 'react-native-google-places-autocomplete';

interface SafeGooglePlacesAutocompleteProps extends GooglePlacesAutocompleteProps {
  /** Optional override, but default is always 'en' per product policy */
  forceLanguage?: string;
  /** Optional override for country bias; default 'us' */
  countryBias?: string;
  /** Optional bias center; default Atlanta */
  biasLat?: number;
  biasLng?: number;
  /** Optional radius meters around bias center */
  biasRadius?: number;
  /** Optional props for the internal FlatList to handle nested scrolling */
  listViewProps?: any;
}

/**
 * Safe wrapper around GooglePlacesAutocomplete that prevents crashes from undefined props
 * Common crash: "Cannot read property 'filter' of undefined" in buildRowsFromResults
 * 
 * Also enforces English language and US/Atlanta bias by default
 */
const SafeGooglePlacesAutocomplete = forwardRef<any, SafeGooglePlacesAutocompleteProps>((props, ref) => {
  const {
    forceLanguage,
    countryBias,
    biasLat,
    biasLng,
    biasRadius,
    listViewProps,
    ...restProps
  } = props;

  // ---------- Opinionated defaults per product policy ----------
  const DEFAULT_LANG = forceLanguage || 'en';
  const DEFAULT_COUNTRY = countryBias || 'us';
  // Atlanta, GA coordinates
  const ATL_LAT = biasLat ?? 33.7490;
  const ATL_LNG = biasLng ?? -84.3880;
  const DEFAULT_RADIUS = biasRadius ?? 80000; // ~80km

  // Get API key from environment if not provided
  const googleApiKey = restProps.query?.key || (Platform.OS === 'ios' 
    ? process.env.EXPO_PUBLIC_GOOGLE_PLACES_API_KEY_IOS
    : process.env.EXPO_PUBLIC_GOOGLE_PLACES_API_KEY_ANDROID);

  // ---------- Build a safe, merged query ----------
  const safeQuery: any = {
    // Caller query first so we can override below
    ...safeSpread(restProps.query),
    key: googleApiKey,
    // FORCE English results regardless of UI language
    language: DEFAULT_LANG,
    // Country/region bias
    components: restProps.query?.components ?? `country:${DEFAULT_COUNTRY}`,
    region: restProps.query?.region ?? DEFAULT_COUNTRY,
    // Location bias near Atlanta unless caller provided
    location: restProps.query?.location ?? `${ATL_LAT},${ATL_LNG}`,
    radius: restProps.query?.radius ?? DEFAULT_RADIUS,
  };

  // Ensure types is an array only when provided
  if (restProps.query?.types) {
    safeQuery.types = toArray(restProps.query.types);
  }

  // Apply same language to details query for formatted_address, etc.
  const safeDetailsQuery = {
    ...safeSpread(restProps.GooglePlacesDetailsQuery),
    language: DEFAULT_LANG,
  };

  // Safe defaults to prevent .filter() crashes
  const safeProps: GooglePlacesAutocompleteProps = {
    ...restProps,
    
    // Ensure predefinedPlaces is always an array
    predefinedPlaces: safeArray(restProps.predefinedPlaces, []),
    
    // Ensure filterReverseGeocodingByTypes is always an array if provided
    filterReverseGeocodingByTypes: restProps.filterReverseGeocodingByTypes 
      ? safeArray(restProps.filterReverseGeocodingByTypes, [])
      : undefined,
    
    // Safe styles object
    styles: safeSpread(restProps.styles),
    
    // Use our enhanced query with bias
    query: safeQuery,
    
    // Apply language to details query as well
    GooglePlacesDetailsQuery: safeDetailsQuery,
    
    // Safe textInputProps
    textInputProps: safeSpread(restProps.textInputProps),
    
    // Safe renderLeftButton and renderRightButton to prevent composition issues
    renderLeftButton: restProps.renderLeftButton || undefined,
    renderRightButton: restProps.renderRightButton || undefined,
    
    // Pass through listViewProps for nested scrolling control
    listViewProps: listViewProps || {},
  };

  return <GooglePlacesAutocomplete ref={ref} {...safeProps} />;
});

SafeGooglePlacesAutocomplete.displayName = 'SafeGooglePlacesAutocomplete';

export default SafeGooglePlacesAutocomplete;