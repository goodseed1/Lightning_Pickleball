import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Platform, ActivityIndicator } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import FeedScreen from '../screens/FeedScreen';
import DiscoverScreen from '../screens/DiscoverScreen';
import CreateScreen from '../screens/CreateScreen';
import MyClubsScreen from '../screens/MyClubsScreen';
import MyProfileScreen from '../screens/MyProfileScreen';
import EditProfileScreen from '../screens/EditProfileScreen';
import UserProfileScreen from '../screens/UserProfileScreen';
import ClubDetailScreen from '../screens/clubs/ClubDetailScreen';
import EventChatScreen from '../screens/EventChatScreen';
import EditEventScreen from '../screens/EditEventScreen';
import RateSportsmanshipScreen from '../screens/RateSportsmanshipScreen';
import ChatbotScreen from '../screens/ChatbotScreen';
import FloatingChatButton from '../components/FloatingChatButton';
import CreationNavigator from './CreationNavigator';
import AuthNavigator from './AuthNavigator';
import OnboardingContainer from '../screens/auth/OnboardingContainer';
import { useLanguage } from '../contexts/LanguageContext';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import CreateClubScreen from '../screens/clubs/CreateClubScreen';

const ClubLeagueManagementScreen = () => (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
    <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 10 }}>🏆 League Management</Text>
    <Text style={{ fontSize: 16, color: '#666' }}>Manage club leagues and seasons</Text>
  </View>
);

const ClubTournamentManagementScreen = () => (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
    <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 10 }}>🥇 Tournament Management</Text>
    <Text style={{ fontSize: 16, color: '#666' }}>Organize and manage tournaments</Text>
  </View>
);

const ClubScheduleSettingsScreen = () => (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
    <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 10 }}>📅 Schedule Settings</Text>
    <Text style={{ fontSize: 16, color: '#666' }}>Configure regular meeting schedules</Text>
  </View>
);

const ClubMemberManagementScreen = () => (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
    <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 10 }}>👥 Member Management</Text>
    <Text style={{ fontSize: 16, color: '#666' }}>Manage club members and permissions</Text>
  </View>
);

const ClubEventManagementScreen = () => (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
    <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 10 }}>⚡ Event Management</Text>
    <Text style={{ fontSize: 16, color: '#666' }}>Create and manage club events</Text>
  </View>
);

const ClubChatScreen = () => (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
    <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 10 }}>💬 Club Chat</Text>
    <Text style={{ fontSize: 16, color: '#666' }}>Member communication and announcements</Text>
  </View>
);

// Simple theme and auth mock
const theme = {
  colors: {
    primary: '#1976d2'
  }
};

// Import the real useAuth hook
import { useAuth } from '../contexts/AuthContext';

// OnboardingScreen wrapper to provide navigation context
const OnboardingScreen = () => {
  const { markOnboardingComplete } = useAuth();
  const navigation = useNavigation();

  const handleOnboardingComplete = (userData: any) => {
    console.log('🚀 AppNavigator: handleOnboardingComplete called');
    console.log('📋 AppNavigator: Received user data:', userData);
    
    // Extract profile data from userData to pass to markOnboardingComplete
    const profileData = userData.profile || userData;
    const mappedProfileData = {
      displayName: profileData.nickname || userData.nickname,
      skillLevel: profileData.skillLevel || userData.skillLevel,
      playingStyle: Array.isArray(profileData.preferredPlayingStyle) 
        ? profileData.preferredPlayingStyle.join(',') 
        : profileData.playingStyle || 'all-court',
      maxTravelDistance: profileData.maxTravelDistance || userData.maxTravelDistance || 15,
      activityRegions: profileData.activityRegions || userData.activityRegions || ['Atlanta Metro'],
      languages: profileData.communicationLanguages || userData.languages || ['English'],
      goals: profileData.goals || userData.goals || null,
      location: profileData.location || userData.location || { 
        lat: 33.7490, 
        lng: -84.3880, 
        address: 'Atlanta, GA' 
      }
    };
    
    console.log('🏁 AppNavigator: Calling markOnboardingComplete() with profile data...');
    console.log('📊 Mapped profile data:', mappedProfileData);
    markOnboardingComplete(mappedProfileData);
    console.log('✅ AppNavigator: markOnboardingComplete() called successfully');
  };

  return (
    <OnboardingContainer
      navigation={navigation}
      onComplete={handleOnboardingComplete}
    />
  );
};

// Custom Create Tab Button Component
const CreateTabButton = (props: any) => {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  
  return (
    <TouchableOpacity
      {...props}
      onPress={() => navigation.navigate('CreateFlow')}
      activeOpacity={0.8}
    />
  );
};

// Remove the placeholder LoginScreen since we have AuthNavigator

export type RootStackParamList = {
  MainTabs: undefined | { screen: keyof MainTabParamList };
  Auth: undefined;
  Onboarding: undefined;
  CreateFlow: undefined;
  ClubDetail: { clubId: string; fallbackClub?: any };
  CreateClub: { clubId?: string; mode?: string };
  ClubLeagueManagement: { clubId: string };
  ClubTournamentManagement: { clubId: string };
  ClubScheduleSettings: { clubId: string };
  ClubMemberManagement: { clubId: string };
  ClubEventManagement: { clubId: string };
  ClubChat: { clubId: string };
  EditProfileScreen: undefined;
  EventChat: { eventId: string; eventTitle?: string };
  EditEvent: { eventId: string };
  UserProfile: { userId: string; nickname?: string };
  RateSportsmanship: { eventId: string; eventType?: string };
  Chatbot: { pageContext?: string };
};

export type MainTabParamList = {
  Feed: undefined;
  Discover: undefined;
  Create: undefined;
  MyClubs: undefined;
  MyProfile: {
    initialTab?: 'information' | 'stats' | 'activity' | 'friends' | 'settings';
    initialActivityTab?: 'applied' | 'hosted' | 'past';
  } | undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<MainTabParamList>();

// 메인 탭 네비게이터
function MainTabNavigator() {
  const { t, currentLanguage } = useLanguage();
  const insets = useSafeAreaInsets();
  const [currentRoute, setCurrentRoute] = React.useState('Feed');

  return (
    <View style={{ flex: 1 }}>
      <Tab.Navigator
        screenOptions={({ route, navigation }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap;

          switch (route.name) {
            case 'Feed':
              iconName = focused ? 'newspaper' : 'newspaper-outline';
              break;
            case 'Discover':
              iconName = focused ? 'search' : 'search-outline';
              break;
            case 'Create':
              iconName = 'add-circle';
              break;
            case 'MyClubs':
              iconName = focused ? 'people' : 'people-outline';
              break;
            case 'MyProfile':
              iconName = focused ? 'person' : 'person-outline';
              break;
            default:
              iconName = 'circle-outline';
          }

          // Create 탭은 더 큰 아이콘
          const iconSize = route.name === 'Create' ? size + 16 : size;
          const iconColor = route.name === 'Create' ? '#1976d2' : color;

          return <Ionicons name={iconName} size={iconSize} color={iconColor} />;
        },
        tabBarActiveTintColor: theme.colors.primary,
        tabBarInactiveTintColor: 'gray',
        tabBarStyle: {
          paddingBottom: Platform.OS === 'android' ? Math.max(35, insets.bottom + 10) : 25, // 안드로이드에서 시스템 네비게이션 바 고려
          paddingTop: 8,
          height: Platform.OS === 'android' ? Math.max(95, 85 + insets.bottom) : 85, // 동적 높이 조정
        },
        headerShown: false,
      })}
      screenListeners={({ navigation, route }) => ({
        state: (e) => {
          // Update current route for FloatingChatButton
          const state = navigation.getState();
          const currentRouteName = state.routes[state.index].name;
          setCurrentRoute(currentRouteName);
        },
      })}
    >
      <Tab.Screen 
        name="Feed" 
        component={FeedScreen}
        options={{ tabBarLabel: t('navigation.feed') }}
      />
      <Tab.Screen 
        name="Discover" 
        component={DiscoverScreen}
        options={{ tabBarLabel: t('navigation.discover') }}
      />
      <Tab.Screen 
        name="Create" 
        component={CreateScreen}
        options={{ 
          tabBarLabel: t('navigation.create'),
          tabBarButton: (props) => <CreateTabButton {...props} />,
        }}
      />
      <Tab.Screen 
        name="MyClubs" 
        component={MyClubsScreen}
        options={{ tabBarLabel: t('navigation.myClubs') }}
      />
      <Tab.Screen 
        name="MyProfile" 
        component={MyProfileScreen}
        options={{ tabBarLabel: t('navigation.myProfile') }}
      />
      </Tab.Navigator>
      
      {/* Global Floating Chat Button */}
      <FloatingChatButton currentRoute={currentRoute} />
    </View>
  );
}

// 메인 앱 네비게이터
export default function AppNavigator() {
  const { currentUser: user, loading: isLoading, isProfileLoaded, isOnboardingComplete } = useAuth();

  // Debug logging for navigation state
  console.log('🧭 AppNavigator: Navigation state check');
  console.log('   - isLoading:', isLoading);
  console.log('   - isProfileLoaded:', isProfileLoaded);
  console.log('   - currentUser:', user ? `${user.email} (${user.uid})` : 'null');
  console.log('   - user.displayName:', user?.displayName);
  console.log('   - isOnboardingComplete:', isOnboardingComplete);
  console.log('   - Navigation decision:', 
    !user ? 'Auth' : 
    !isProfileLoaded ? 'ProfileLoading' :
    !isOnboardingComplete ? 'Onboarding' : 
    'MainTabs'
  );

  // 🔄 로딩 상태들을 처리
  if (isLoading) {
    console.log('🧭 AppNavigator: Showing auth loading state');
    return null; // 또는 로딩 스크린
  }

  // ✅ 핵심: 사용자가 있지만 프로필이 아직 로딩 중이면 로딩 스피너 표시
  if (user && !isProfileLoaded) {
    console.log('🧭 AppNavigator: User exists but profile still loading - showing profile loading spinner');
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f5f5f5' }}>
        <ActivityIndicator size="large" color="#1976d2" />
        <Text style={{ marginTop: 16, fontSize: 16, color: '#666' }}>
          프로필을 불러오는 중...
        </Text>
        <Text style={{ marginTop: 8, fontSize: 14, color: '#999' }}>
          Loading profile data...
        </Text>
      </View>
    );
  }

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: theme.colors.primary,
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
    >
      {!user ? (
        // 비로그인 사용자 - 인증 플로우
        <Stack.Screen 
          name="Auth" 
          component={AuthNavigator}
          options={{ headerShown: false }}
        />
      ) : !isOnboardingComplete ? (
        // 로그인했지만 온보딩 미완료 - 온보딩 플로우
        <Stack.Screen 
          name="Onboarding" 
          component={OnboardingScreen}
          options={{ headerShown: false }}
        />
      ) : (
        // 로그인 및 온보딩 완료 - 메인 앱
        <>
          <Stack.Screen 
            name="MainTabs" 
            component={MainTabNavigator}
            options={{ headerShown: false }}
          />
          <Stack.Screen 
            name="CreateFlow" 
            component={CreationNavigator}
            options={{ 
              headerShown: false,
              presentation: 'modal'
            }}
          />
          <Stack.Screen 
            name="ClubDetail" 
            component={ClubDetailScreen}
            options={{ 
              title: '클럽 정보',
              headerShown: true
            }}
          />
          <Stack.Screen 
            name="CreateClub" 
            component={CreateClubScreen}
            options={{ 
              title: '새 클럽 만들기',
              headerShown: true
            }}
          />
          <Stack.Screen 
            name="ClubLeagueManagement" 
            component={ClubLeagueManagementScreen}
            options={{ 
              title: '리그 관리',
              headerShown: true
            }}
          />
          <Stack.Screen 
            name="ClubTournamentManagement" 
            component={ClubTournamentManagementScreen}
            options={{ 
              title: '토너먼트 관리',
              headerShown: true
            }}
          />
          <Stack.Screen 
            name="ClubScheduleSettings" 
            component={ClubScheduleSettingsScreen}
            options={{ 
              title: '정기 모임 설정',
              headerShown: true
            }}
          />
          <Stack.Screen 
            name="ClubMemberManagement" 
            component={ClubMemberManagementScreen}
            options={{ 
              title: '멤버 관리',
              headerShown: true
            }}
          />
          <Stack.Screen 
            name="ClubEventManagement" 
            component={ClubEventManagementScreen}
            options={{ 
              title: '이벤트 관리',
              headerShown: true
            }}
          />
          <Stack.Screen 
            name="ClubChat" 
            component={ClubChatScreen}
            options={{ 
              title: '클럽 채팅',
              headerShown: true
            }}
          />
          <Stack.Screen 
            name="EditProfileScreen" 
            component={EditProfileScreen}
            options={{ 
              title: '프로필 수정',
              headerShown: true
            }}
          />
          <Stack.Screen 
            name="EventChat" 
            component={EventChatScreen}
            options={{ 
              title: '이벤트 채팅',
              headerShown: false
            }}
          />
          <Stack.Screen 
            name="EditEvent" 
            component={EditEventScreen}
            options={{ 
              title: '이벤트 수정',
              headerShown: false
            }}
          />
          <Stack.Screen 
            name="UserProfile" 
            component={UserProfileScreen}
            options={{ 
              title: '사용자 프로필',
              headerShown: true
            }}
          />
          <Stack.Screen 
            name="RateSportsmanship" 
            component={RateSportsmanshipScreen}
            options={{ 
              title: '스포츠맨십 평가',
              headerShown: false
            }}
          />
          <Stack.Screen 
            name="Chatbot" 
            component={ChatbotScreen}
            options={{ 
              title: 'AI 도움말',
              headerShown: false
            }}
          />
        </>
      )}
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1976d2',
    marginBottom: 10,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 18,
    color: '#333',
    marginBottom: 15,
    textAlign: 'center',
  },
  description: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    lineHeight: 20,
  },
});